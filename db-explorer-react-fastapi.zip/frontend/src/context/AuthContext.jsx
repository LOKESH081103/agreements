import { createContext, useCallback, useContext, useEffect, useState } from "react";
import api from "../api.js";

const AuthContext = createContext(null);

function readUser() {
  try { return JSON.parse(localStorage.getItem("user")) || null; } catch { return null; }
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(readUser);
  const logout = useCallback(() => { localStorage.removeItem("token"); localStorage.removeItem("user"); setUser(null); }, []);
  useEffect(() => { const onExpired = () => logout(); window.addEventListener("auth-expired", onExpired); return () => window.removeEventListener("auth-expired", onExpired); }, [logout]);
  const login = useCallback(async (employee_code, password) => { const { data } = await api.post("/auth/login", { employee_code, password }); const nextUser = { employee_code: data.employee_code, access_level: data.access_level }; localStorage.setItem("token", data.token); localStorage.setItem("user", JSON.stringify(nextUser)); setUser(nextUser); return nextUser; }, []);
  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}
export function useAuth() { return useContext(AuthContext); }
