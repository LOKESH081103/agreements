import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { errorMessage } from "../api.js";

export default function Login() {
  const { login } = useAuth(); const [employeeCode, setEmployeeCode] = useState(""); const [password, setPassword] = useState(""); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(event) { event.preventDefault(); setError(""); setBusy(true); try { await login(employeeCode.trim(), password); } catch (e) { setError(errorMessage(e, "Login failed.")); } finally { setBusy(false); } }
  return <div className="login-shell"><div className="login-brand-panel"><div className="login-brand-content"><div className="sidebar-brand-icon">▦</div><h1>DB Explorer &amp;<br />Report Generator</h1><p>Explore your PostgreSQL data, build reports, and summarize large tables without locking the interface.</p></div></div><div className="login-form-panel"><div className="card card-pad fade-in" style={{ width: "100%", maxWidth: 400 }}><h2>Welcome back</h2><p style={{ margin: "8px 0 22px" }}>Sign in to continue to your workspace.</p>{error && <div className="banner banner-error">{error}</div>}<form onSubmit={submit}><div className="field"><label>Employee code</label><input value={employeeCode} onChange={(e) => setEmployeeCode(e.target.value)} required autoFocus /></div><div className="field"><label>Password</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></div><button type="submit" disabled={busy} className="btn btn-primary" style={{ width: "100%" }}>{busy ? <><span className="spinner" /> Signing in…</> : "Sign in"}</button></form></div></div></div>;
}
