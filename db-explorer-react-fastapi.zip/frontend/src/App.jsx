import { useState } from "react";
import { useAuth } from "./context/AuthContext.jsx";
import Login from "./components/Login.jsx";
import TableExplorer from "./components/TableExplorer.jsx";
import PivotBuilder from "./components/PivotBuilder.jsx";

const NAV_ITEMS = [
  { key: "report", label: "Report Generator", icon: "▦", desc: "Explore tables and build reports" },
  { key: "pivot", label: "Pivot Builder", icon: "◫", desc: "Summarize data with Excel-style pivots" },
];

export default function App() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState("report");
  if (!user) return <Login />;
  const active = NAV_ITEMS.find((item) => item.key === tab) || NAV_ITEMS[0];
  const initials = (user.employee_code || "U").slice(0, 2).toUpperCase();
  return <div className="app-shell"><aside className="sidebar"><div className="sidebar-brand"><div className="sidebar-brand-icon">▦</div><div><div className="sidebar-brand-text">DB Explorer</div><div className="sidebar-brand-sub">FastAPI workspace</div></div></div><nav className="sidebar-nav">{NAV_ITEMS.map((item) => <button key={item.key} className={`sidebar-link ${tab === item.key ? "active" : ""}`} onClick={() => setTab(item.key)}><span className="icon">{item.icon}</span>{item.label}</button>)}</nav><div className="sidebar-footer"><div className="sidebar-user"><div className="sidebar-avatar">{initials}</div><div><div className="sidebar-user-name">{user.employee_code}</div><div className="sidebar-user-role">{user.access_level}</div></div></div><button className="sidebar-logout" onClick={logout}>Logout</button></div></aside><div className="main-area"><header className="topbar"><div><div className="topbar-title">{active.label}</div><div className="topbar-sub">{active.desc}</div></div><span className="badge badge-success">{user.access_level}</span></header><main className="content fade-in" key={tab}>{tab === "report" ? <TableExplorer /> : <PivotBuilder />}</main></div></div>;
}
