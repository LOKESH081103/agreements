# DB Explorer React + FastAPI

This project keeps the supplied `app.py` Streamlit application and shared `db_core.py` logic, while adding a React frontend connected directly to the supplied FastAPI service.

## Run the API

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit DATABASE_URL and JWT_SECRET
uvicorn api:app --host 0.0.0.0 --port 8000 --reload
```

The API creates the shared auth tables on startup and exposes `/auth/login`, `/tables`, `/tables/{table}/columns`, report endpoints, pivot endpoints, and Excel exports.

## Run the frontend

```bash
cd frontend
npm install
npm run dev
```

Set `VITE_API_URL=http://localhost:8000` when the API is not running on the default local port.

## Why the screen stays responsive

The React client uses asynchronous Axios requests, aborts superseded requests when the user changes tables or reruns a report, limits report responses to 5,000 rows, renders only the first 500 rows in the visible table, and loads independent pivot requests concurrently. FastAPI synchronous database handlers are executed through FastAPI's worker threadpool, so a database query does not block the event loop.

The existing Streamlit application is retained as `backend/app.py` for users who still need the original UI. The React UI exposes the FastAPI-backed report and pivot workflows; the old Node-only SQL and admin routes were not part of the supplied FastAPI contract.

## Pivot behavior

The Values selector supports multiple numeric fields. For example, selecting `stage_ecl` as a row and `March 25` plus `April 25` as Values produces grouped headers such as `sum of March 25` and `sum of April 25` in both the browser matrix and summary Excel export. After computing Field Efficiency, the **Download efficiency Excel** action exports the percentage matrix separately. The redundant flat “Pivot rows” panel is intentionally not shown.
