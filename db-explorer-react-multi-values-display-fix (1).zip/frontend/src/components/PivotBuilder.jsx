import { useEffect, useRef, useState } from "react";
import api, { downloadBlob, errorMessage, isCanceled, pivotPayload } from "../api.js";

const AGG_FUNCS = ["sum", "mean", "count", "min", "max"];

export default function PivotBuilder() {
  const [tables, setTables] = useState([]);
  const [table, setTable] = useState("");
  const [columns, setColumns] = useState([]);
  const [rowCols, setRowCols] = useState([]);
  const [colCols, setColCols] = useState([]);
  const [valueCols, setValueCols] = useState([]);
  const [aggFunc, setAggFunc] = useState("sum");
  const [inCrores, setInCrores] = useState(false);
  const [matrix, setMatrix] = useState(null);
  const [efficiency, setEfficiency] = useState(null);
  const [normalizeField, setNormalizeField] = useState("");
  const [busy, setBusy] = useState(false);
  const [efficiencyBusy, setEfficiencyBusy] = useState(false);
  const [error, setError] = useState("");
  const requestRef = useRef(null);

  useEffect(() => {
    const controller = new AbortController();
    api.get("/tables", { signal: controller.signal })
      .then(({ data }) => setTables(data))
      .catch((e) => !isCanceled(e) && setError(errorMessage(e, "Could not load tables.")));
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!table) return;
    const controller = new AbortController();
    setColumns([]); setRowCols([]); setColCols([]); setValueCols([]); setMatrix(null); setEfficiency(null);
    api.get(`/tables/${encodeURIComponent(table)}/columns`, { signal: controller.signal })
      .then(({ data }) => setColumns(data))
      .catch((e) => !isCanceled(e) && setError(errorMessage(e, "Could not load columns.")));
    return () => controller.abort();
  }, [table]);

  const numericColumns = columns.filter((column) => column.kind === "numeric");
  const allFields = columns.map((column) => column.name);
  const payload = pivotPayload({ rowCols, colCols, valueCols, aggFunc, inCrores });

  function toggle(setter, value) {
    setter((current) => current.includes(value) ? current.filter((item) => item !== value) : [...current, value]);
  }

  async function buildPivot() {
    if (!table || !rowCols.length || !valueCols.length) return;
    requestRef.current?.abort();
    const controller = new AbortController();
    requestRef.current = controller;
    setBusy(true); setError(""); setEfficiency(null);
    try {
      // Send one explicit value_col per request and merge the matrices. This
      // also works safely when an already-running API process still has the
      // older single-value schema loaded; every checked field is guaranteed a
      // request of its own instead of relying on a server-side list parser.
      const responses = await Promise.all(valueCols.map((valueCol) => api.post(
        `/tables/${encodeURIComponent(table)}/pivot/matrix`,
        { ...payload, value_col: valueCol, value_cols: [valueCol] },
        { signal: controller.signal },
      )));
      setMatrix(mergeMatrices(responses.map(({ data }) => data), valueCols));
    } catch (e) {
      if (!isCanceled(e)) setError(errorMessage(e, "Pivot build failed."));
    } finally {
      if (!controller.signal.aborted) setBusy(false);
    }
  }

  async function buildEfficiency() {
    if (!normalizeField || !valueCols.length) return;
    setEfficiencyBusy(true); setError("");
    try {
      const { data } = await api.post(`/tables/${encodeURIComponent(table)}/pivot/efficiency`, {
        ...payload,
        normalize_field: normalizeField,
      });
      setEfficiency(data);
    } catch (e) {
      setError(errorMessage(e, "Field efficiency calculation failed."));
    } finally {
      setEfficiencyBusy(false);
    }
  }

  async function downloadSummary() {
    try {
      await downloadBlob(
        api.post(`/tables/${encodeURIComponent(table)}/pivot/matrix.xlsx`, payload, { responseType: "blob" }),
        `${table}_summary_pivot.xlsx`,
      );
    } catch (e) { setError(errorMessage(e, "Summary Excel export failed.")); }
  }

  async function downloadEfficiency() {
    if (!normalizeField) return;
    try {
      await downloadBlob(
        api.post(`/tables/${encodeURIComponent(table)}/pivot/efficiency.xlsx`, { ...payload, normalize_field: normalizeField }, { responseType: "blob" }),
        `${table}_field_efficiency.xlsx`,
      );
    } catch (e) { setError(errorMessage(e, "Field efficiency Excel export failed.")); }
  }

  return (
    <div className="pivot-workspace">
      {error && <div className="banner banner-error">{error}</div>}
      <section className="pivot-hero">
        <div><div className="eyebrow">ANALYSIS WORKSPACE</div><h1>Build a confirmation-ready pivot</h1><p>Choose your row hierarchy, column breakdown, and one or more Values fields. Each selected value becomes its own grouped set of columns in the matrix and Excel export.</p></div>
        <div className="pivot-hero-mark">Σ</div>
      </section>

      <section className="card card-pad pivot-config-card">
        <div className="config-heading"><div><div className="section-title">Pivot configuration</div><p className="config-help">Example: Rows = <strong>stage_ecl</strong>, Values = <strong>March 25</strong> and <strong>April 25</strong>.</p></div><span className="config-step">01 · Configure</span></div>
        <Field label="Data table"><select value={table} onChange={(e) => setTable(e.target.value)}><option value="">Choose a table</option>{tables.map((name) => <option key={name} value={name}>{name}</option>)}</select></Field>
        {columns.length > 0 && <div className="pivot-field-grid">
          <Field label="Rows · required"><ChipPicker options={allFields} selected={rowCols} onToggle={(value) => toggle(setRowCols, value)} /></Field>
          <Field label="Columns · optional"><ChipPicker options={allFields} selected={colCols} onToggle={(value) => toggle(setColCols, value)} /></Field>
          <Field label="Values · select multiple"><CheckboxPicker options={numericColumns.map((column) => column.name)} selected={valueCols} onToggle={(value) => toggle(setValueCols, value)} /><div className="selected-values-line"><strong>{valueCols.length}</strong> selected{valueCols.length > 0 && <>: {valueCols.map((value) => <span className="selected-value-pill" key={value}>{value}</span>)}</>}</div><small className="field-hint">Every checked field is sent and displayed as a separate output column.</small></Field>
          <Field label="Aggregation"><select value={aggFunc} onChange={(e) => setAggFunc(e.target.value)}>{AGG_FUNCS.map((name) => <option key={name}>{name}</option>)}</select></Field>
        </div>}
        <div className="config-footer"><label className="checkbox-row"><input type="checkbox" checked={inCrores} onChange={(e) => setInCrores(e.target.checked)} /> Show numeric values in Crores</label><button className="btn btn-primary pivot-build-button" disabled={!table || !rowCols.length || !valueCols.length || busy} onClick={buildPivot}>{busy ? <><span className="spinner" /> Building matrix…</> : "Build confirmation matrix"}</button></div>
      </section>

      {matrix && <section className="card card-pad result-card fade-in"><div className="result-heading"><div><span className="result-kicker">02 · Review</span><h2>Summary matrix</h2><p>Multiple Values are grouped into separate columns, ready for confirmation and export.</p></div><button className="btn btn-secondary" onClick={downloadSummary}>Download summary Excel</button></div><PivotTable matrix={matrix} /></section>}

      {matrix && <section className="card card-pad result-card fade-in"><div className="result-heading"><div><span className="result-kicker">03 · Optional analysis</span><h2>Field efficiency</h2><p>Normalize the selected value by a field to compare each group as a percentage.</p></div><div className="result-actions"><button className="btn btn-secondary" disabled={!normalizeField || efficiencyBusy} onClick={buildEfficiency}>{efficiencyBusy ? <><span className="spinner spinner-dark" /> Computing…</> : "Compute efficiency"}</button>{efficiency && <button className="btn btn-primary" onClick={downloadEfficiency}>Download efficiency Excel</button>}</div></div><div className="efficiency-controls"><Field label="Normalize by field"><select value={normalizeField} onChange={(e) => setNormalizeField(e.target.value)}><option value="">Choose a field</option>{[...rowCols, ...colCols].map((field) => <option key={field}>{field}</option>)}</select></Field></div>{efficiency && <PivotTable matrix={efficiency} percent />}</section>}
    </div>
  );
}

function PivotTable({ matrix, percent = false }) {
  const depth = matrix.columns?.[0]?.tuple?.length || 1;
  return <div className="table-wrap matrix-wrap"><table className="data-table pivot-table"><thead>{Array.from({ length: depth }, (_, level) => <tr key={level}><th>{level === 0 ? matrix.row_axis_name : ""}</th>{matrix.columns.map((column, index) => <th key={index} className={column.is_total ? "total-header" : ""}>{column.tuple[level]}</th>)}</tr>)}</thead><tbody>{matrix.rows.map((row, index) => <tr key={index} className={row.is_group ? "group-row" : ""}><td className="matrix-label">{row.label}</td>{row.values.map((value, columnIndex) => <td key={columnIndex} className={matrix.columns[columnIndex]?.is_total ? "total-cell" : ""}>{value == null ? "—" : `${Number(value).toLocaleString(undefined, { maximumFractionDigits: 2 })}${percent ? "%" : ""}`}</td>)}</tr>)}</tbody></table></div>;
}

function Field({ label, children }) { return <div className="field"><label>{label}</label>{children}</div>; }
function ChipPicker({ options, selected, onToggle }) { return <div className="chip-picker">{options.map((option) => <button type="button" key={option} className={`chip ${selected.includes(option) ? "active" : ""}`} onClick={() => onToggle(option)}>{option}</button>)}</div>; }
function CheckboxPicker({ options, selected, onToggle }) { return <div className="checkbox-picker">{options.map((option) => <label className={`value-check ${selected.includes(option) ? "selected" : ""}`} key={option}><input type="checkbox" checked={selected.includes(option)} onChange={() => onToggle(option)} /><span className="checkmark">{selected.includes(option) ? "✓" : ""}</span><span title={option}>{option}</span></label>)}</div>; }

function mergeMatrices(matrices, valueCols) {
  const first = matrices[0];
  if (!first) return null;
  const rows = first.rows.map((row, rowIndex) => ({
    ...row,
    values: matrices.flatMap((matrix) => matrix.rows[rowIndex]?.values || []),
  }));
  const columns = matrices.flatMap((matrix, matrixIndex) => matrix.columns.map((column) => {
    const tuple = [...column.tuple];
    if (tuple.length === 1) tuple[0] = `sum of ${valueCols[matrixIndex]}`;
    else tuple[0] = `sum of ${valueCols[matrixIndex]}`;
    return { ...column, tuple };
  }));
  return { ...first, selected_values: valueCols, columns, rows };
}
