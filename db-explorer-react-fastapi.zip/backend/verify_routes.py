import api

expected = {
    "/auth/login", "/auth/me", "/tables", "/tables/{table_name}/columns",
    "/tables/{table_name}/report", "/tables/{table_name}/pivot/matrix",
    "/tables/{table_name}/pivot/matrix.xlsx", "/tables/{table_name}/pivot/efficiency",
    "/tables/{table_name}/pivot/efficiency.xlsx", "/tables/{table_name}/pivot/flat",
}
actual = {route.path for route in api.app.routes}
missing = expected - actual
if missing:
    raise SystemExit(f"Missing routes: {sorted(missing)}")
print(f"OK FastAPI app loaded with {len(actual)} routes")
print("OK required routes present")
