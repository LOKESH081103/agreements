import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000",
  timeout: 120000,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.dispatchEvent(new Event("auth-expired"));
    }
    return Promise.reject(error);
  },
);

export function errorMessage(error, fallback = "Something went wrong") {
  return error?.response?.data?.detail || error?.response?.data?.error || error?.message || fallback;
}

export function isCanceled(error) {
  return error?.code === "ERR_CANCELED" || error?.name === "CanceledError";
}

export function reportPayload(refColumn, refKind, outputColumns, filterPayload) {
  return {
    ref_column: refColumn,
    ref_kind: refKind,
    output_columns: outputColumns,
    filter_payload: filterPayload,
    limit: 5000,
  };
}

export function pivotPayload({ rowCols, colCols, valueCols = [], valueCol = null, aggFunc, inCrores = false, filters = {}, dpdSlabField = null, dpdOnlyShowBuckets = true }) {
  return {
    row_cols: rowCols,
    col_cols: colCols,
    value_cols: valueCols.length ? valueCols : (valueCol ? [valueCol] : []),
    value_col: valueCol || (valueCols[0] || null),
    agg_func: aggFunc,
    in_crores: inCrores,
    filters,
    dpd_slab_field: dpdSlabField,
    dpd_only_show_buckets: dpdOnlyShowBuckets,
  };
}

export async function downloadBlob(request, filename) {
  const response = await request;
  const url = URL.createObjectURL(response.data);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default api;
