import { useEffect, useState } from "react";
import api from "../api.js";

export default function AdminPanel() {
  const [employees, setEmployees] = useState([]);
  const [error, setError] = useState("");

  function load() {
    api
      .get("/auth/employees")
      .then((r) => setEmployees(r.data))
      .catch((e) => setError(e.response?.data?.error || e.message));
  }

  useEffect(load, []);

  async function setAccessLevel(code, access_level) {
    await api.patch(`/auth/employees/${code}/access-level`, { access_level });
    load();
  }

  async function toggleAuthorized(code) {
    await api.patch(`/auth/employees/${code}/toggle-authorized`);
    load();
  }

  const badgeClass = (level) => (level === "admin" ? "badge-admin" : level === "analyst" ? "badge-analyst" : "badge-user");

  return (
    <div>
      {error && <div className="banner banner-error">❌&nbsp; {error}</div>}

      <div className="card card-pad">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
          <div className="section-title" style={{ marginBottom: 0 }}>
            🛠️ Employee Access &nbsp;<span style={{ color: "var(--text-muted)", fontWeight: 500 }}>· {employees.length} total</span>
          </div>
        </div>

        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                {["Employee Code", "Name", "Access Level", "Status", "Last Login", ""].map((h) => (
                  <th key={h}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((e) => (
                <tr key={e.employee_code}>
                  <td><code style={{ fontSize: 12.5 }}>{e.employee_code}</code></td>
                  <td>{e.employee_name || <span style={{ color: "var(--text-muted)" }}>—</span>}</td>
                  <td>
                    <select
                      value={e.access_level}
                      onChange={(ev) => setAccessLevel(e.employee_code, ev.target.value)}
                      style={{ fontSize: 12.5, padding: "5px 8px" }}
                    >
                      <option value="user">user</option>
                      <option value="analyst">analyst</option>
                      <option value="admin">admin</option>
                    </select>
                    <span className={`badge ${badgeClass(e.access_level)}`} style={{ marginLeft: 8 }}>
                      {e.access_level}
                    </span>
                  </td>
                  <td>
                    <span className={`badge ${e.is_authorized ? "badge-success" : "badge-danger"}`}>
                      {e.is_authorized ? "✅ Active" : "🚫 Revoked"}
                    </span>
                  </td>
                  <td>{e.last_login ? new Date(e.last_login).toLocaleString() : <span style={{ color: "var(--text-muted)" }}>—</span>}</td>
                  <td>
                    <button
                      onClick={() => toggleAuthorized(e.employee_code)}
                      className={`btn btn-sm ${e.is_authorized ? "btn-danger-outline" : "btn-secondary"}`}
                    >
                      {e.is_authorized ? "Revoke" : "Restore"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {!employees.length && !error && (
          <div className="empty-state">
            <div className="empty-state-icon">👥</div>
            No employees found.
          </div>
        )}
      </div>
    </div>
  );
}
