function formatNum(value) { return Number(value ?? 0).toLocaleString(undefined, { maximumFractionDigits: 2 }); }

export default function KpiCards({ numericCols = [], kpis }) {
  if (!kpis) return null;
  return <div className="kpi-grid fade-in"><Card label="Record Count" value={formatNum(kpis.record_count)} />{numericCols.map((column) => { const item = kpis[column] || {}; return <Card key={column} label={`Sum of ${column}`} value={formatNum(item.sum)} sub={`avg ${formatNum(item.avg)} · min ${formatNum(item.min)} · max ${formatNum(item.max)}`} />; })}</div>;
}
function Card({ label, value, sub }) { return <div className="kpi-card"><div className="kpi-label">{label}</div><div className="kpi-value">{value}</div>{sub && <div className="kpi-sub">{sub}</div>}</div>; }
