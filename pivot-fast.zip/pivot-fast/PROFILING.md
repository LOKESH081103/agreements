# Profiling the Fast Pivot Summary

This bundle contains full replacement `app.py` and `db_core.py` files. Install both together as described in [README.md](README.md). Keep your normal database credentials private. Profiling logs are enabled by default; set `PIVOT_PROFILE=0` to silence Python timings.

## 1. Run a comparable test

1. Start the app from the project directory and open the same table, filters, Rows, Columns, Values, and aggregation that felt slow.
2. Keep the Streamlit server terminal visible. Timing lines are printed there with the prefix `[PIVOT_PROFILE]`.
3. For a **cold** test, use Streamlit's menu to clear the app cache, then build the pivot once. Repeat the identical build for a **warm** test. The cold test includes database work; the warm test may be served from cache.
4. By default, the summary grid shows one Values measure and 100 rows per page. This limits what is sent to the browser, while the complete matrix is retained on the server for exports. Choose **All Values fields (larger grid)** only to inspect every measure side by side.
5. If testing Field Efficiency, select one Values field first. Choose all measures only if you want to test that slower, broader optional calculation.

## 2. Understand the timing lines

| Timing stage | What it measures |
|---|---|
| `fetch_call_including_cache` | Time spent at the app's source-fetch call, including Streamlit cache lookup/return. It reports grouped rows per Values field. |
| `db_query_and_dataframe_fetch` | Appears on a source-cache miss. Measures the SQL round trip through delivery/materialization of the grouped result in pandas. This combines PostgreSQL execution, network transfer, and pandas loading; it is not pure server execution time. |
| `python_pivot_build_shared` | Time around the shared multi-measure Summary Matrix builder, including Streamlit cache lookup/return. On a cold builder-cache miss, this includes the actual shared layout, group-by, and matrix construction. It reports measures, full matrix dimensions, and cells. |
| `python_pivot_build` | Summary Matrix builder timing when exactly one Values field is selected. |
| `python_efficiency_build` | Separate optional Field Efficiency build, with the number of Values measures calculated. It is absent when Field Efficiency is not requested. |
| `grid_prepare` | Server time to build records and column definitions for the **current measure selection and current page only**. The line includes page rows and total matrix rows. |
| `aggrid_server_call` | Time in the Python call that hands the current page to AgGrid. It does not prove the browser has finished drawing. |

The new shared build replaces the old `python_measure_pivot_build` lines (one expensive build per Values field) and `python_pivot_build_total` assembly line. Expect to see `python_pivot_build_shared` instead. The complete matrix dimensions can still grow with the number of selected Values fields even though the visible grid defaults to one field.

The database timing appears only when the source query misses cache. The shared-builder timing may include a cache hit too. Compare cold with cold and warm with warm. Changing Rows/Columns, filters, aggregation, totals, or measure selection can produce a different cache key.

## 3. Ask PostgreSQL for its execution plan

The Python fetch timer cannot isolate PostgreSQL execution from network and pandas time. To obtain a server-side plan:

1. Restart the app with SQL logging enabled.

   Linux/macOS:

   ```bash
   export PIVOT_PROFILE=1
   export PIVOT_PROFILE_SQL=1
   streamlit run app.py
   ```

   Windows PowerShell:

   ```powershell
   $env:PIVOT_PROFILE = "1"
   $env:PIVOT_PROFILE_SQL = "1"
   streamlit run app.py
   ```

2. Clear the Streamlit cache and build your representative pivot once. Copy the `[PIVOT_SQL]` query from the server terminal. The app intentionally does not print filter values.
3. In pgAdmin Query Tool, `psql`, or another authorized SQL console on the same database, substitute the placeholders with the values from your own selected filters, properly quoting text/date literals. Keep the same table, groupings, Values fields, and filters.
4. Prefix the SELECT with:

   ```sql
   EXPLAIN (ANALYZE, BUFFERS, VERBOSE, SETTINGS)
   SELECT ...;
   ```

5. Run once, preferably off-peak. `ANALYZE` actually executes the SELECT and can load a production database. If you lack permission or the query is too costly, ask your DBA to run it. Do not send credentials or sensitive literals in a shared ticket.

Look at PostgreSQL's `Execution Time`, actual rows/timing per node, shared/disk buffers, and temporary reads/writes. A sequential scan is not automatically a problem; for broad reports it can be the correct plan. Review the plan and actual filters before adding indexes.

## 4. Separate server work from browser rendering

The grid now sends only the selected Values block and current row page by default. To test all-columns browser rendering, explicitly choose **All Values fields** and note that this increases browser payload. Open Chrome/Edge Developer Tools before the test:

- **Network:** inspect Streamlit WebSocket frames; large transfers indicate a larger-than-needed payload.
- **Performance:** record the interaction and inspect long scripting/render tasks after the server sends data.

`aggrid_server_call` times only the Python component call. Browser drawing happens separately and is not accurately timed by `perf_counter()` in this app.

## 5. What to collect

For one slow, representative run, collect:

1. All `[PIVOT_PROFILE]` lines for the run, redacting table/field names if sensitive.
2. Whether it was cache-cold or warm, plus grouped-row counts, measure count, full matrix rows/columns/cells, and page size.
3. A redacted `EXPLAIN (ANALYZE, BUFFERS, VERBOSE, SETTINGS)` plan if available.
4. Whether the browser paused after the server logs finished, and whether one-measure or all-measures view was selected.

Disable the timing log with `PIVOT_PROFILE=0`. Set `PIVOT_PROFILE_SQL=0` when query text is no longer needed; avoid leaving SQL logging on unnecessarily.
