# Fast Pivot Summary — replacement project

This folder contains complete replacement `app.py` and `db_core.py` files for the PostgreSQL/Streamlit project, plus tests and setup/profiling instructions. **Replace both Python files together**; the updated app calls the shared multi-measure function in the updated core module. Your original uploaded files and the earlier profiling bundle have not been changed.

## What changed

- **One shared multi-measure pivot build:** the app no longer runs the full Excel-style pivot builder separately for every Values field. It builds row/column hierarchies once, groups the chosen statistics for all Values fields together, and batches lookups by hierarchy level.
- **Default light screen view:** with multiple Values fields, the Summary Matrix grid shows the first Values field by default. Choose another measure or **All Values fields (larger grid)** from the selector when needed. The complete all-measure matrix is still built and remains available to the existing Excel/export and downstream calculations.
- **Row paging:** the Summary Matrix and Field Efficiency grids show 100 rows per page by default, with 50/100/250 page-size choices. This reduces browser rendering and data-transfer work; it does not remove rows from the complete matrix.
- **Field Efficiency is opt-in and defaults to one measure:** enabling it no longer automatically computes every selected month. Choose **All Values fields (takes longer)** only when you need every efficiency block.
- **Larger automatic render thresholds:** the guard now permits paged pivots up to 50,000 estimated rows and 10 million full-matrix cells; larger pivots still have an explicit override and warning.
- **Streamlit width warning fixed:** deprecated `use_container_width=True` arguments were replaced with `width="stretch"`.
- **Separate timings:** logs distinguish shared summary construction, optional efficiency construction, page preparation, and the AgGrid server call.

The core calculation was benchmarked here against a synthetic 35,782-group/18-measure workload with about 2.8 million output cells: the new shared builder completed in about **0.8 seconds** in this sandbox. That is a useful algorithmic check, not a promise for your hardware or a direct before/after test against your exact data. Your actual database fetch, filters, hierarchy cardinality, and matrix size determine end-to-end time.

## Install / replace

1. Stop the app.
2. Back up your current `app.py` and `db_core.py`.
3. Copy the two replacement files from this folder into the project folder, overwriting **both** files.
4. Keep your existing `.env`, Streamlit secrets, database settings, and other project files private and unchanged.
5. In your existing virtual environment, install/update dependencies if required:

   ```bash
   python -m pip install -r requirements.txt
   ```

6. Start Streamlit from the project folder as usual:

   ```bash
   streamlit run app.py
   ```

If your project already has its own pinned requirements, keep those pins but make sure Streamlit is at least 1.49 for the `width="stretch"` API.

## Use the faster Summary Matrix

1. Build the same pivot as before; the database fetch and selected aggregation semantics remain unchanged.
2. With one Values field, the table displays it directly.
3. With multiple Values fields, the first is displayed in the grid by default. Use **Values field to show in the grid** to change the displayed measure. Choose **All Values fields (larger grid)** only when you want all of the measure columns visible at once.
4. Use **Rows per page** and **Page** below the matrix to navigate the row hierarchy. The grid starts at 100 rows per page.
5. Excel and other downstream features continue to use the complete pivot result, not just the current screen page/measure. Preparing a formatted workbook is still optional and may take additional time for a very large matrix.
6. Field Efficiency remains unchecked by default. When enabled for multiple Values fields, the first measure is calculated by default; choose **All Values fields (takes longer)** if you need all months' efficiency tables. Its own timing is logged as `python_efficiency_build`.

The automatic memory guard is based on the **complete** matrix because that all-measure result remains available for exports. If it stops a very large pivot, apply filters/remove high-cardinality fields first; use the explicit override only when the server has enough memory and you accept the risk.

## Validate without a database

From this folder, run:

```bash
python -m py_compile app.py db_core.py test_multi_measure_pivot.py test_shared_multi_pivot.py
python -m unittest -v test_multi_measure_pivot.py test_shared_multi_pivot.py
```

These checks cover the one-query multi-measure source fetch and compare the new shared result with the established per-measure builder for sum, mean, count, min, and max; subtotal modes; date hierarchies; column order; and differently ordered measure inputs. They do not require database credentials.

## Profiling and PostgreSQL instructions

See [PROFILING.md](PROFILING.md) for cache-cold/warm timing, log interpretation, browser timing, and safe PostgreSQL `EXPLAIN (ANALYZE, BUFFERS, ...)` steps. Do not share credentials or unredacted sensitive filter values.
