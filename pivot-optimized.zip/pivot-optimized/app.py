"""
Dynamic PostgreSQL Explorer & Report Generator
================================================
A production-ready Streamlit application that lets a user pick any table
in a PostgreSQL database, filter it by a reference column (date/timestamp
or categorical), pick one or more output columns, and view/download the
resulting report with auto-generated KPI cards for numeric columns.

Run with:
    streamlit run app.py
Configuration is read from environment variables (see .env.example / README).
"""

from __future__ import annotations

import io
import itertools
import os
import re
from typing import Any

import numpy as np
import pandas as pd
import streamlit as st
from st_aggrid import AgGrid, JsCode
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError

# --------------------------------------------------------------------------- #
# Page configuration
# --------------------------------------------------------------------------- #
st.set_page_config(
    page_title="DB Explorer & Report Generator",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Fallback safety net: any remaining `.style.format(...)` call on a large
# DataFrame (e.g. a table the AgGrid renderer itself had to fall back away
# from) raises instead of silently truncating/crashing once it exceeds
# pandas' default styler element cap (~262k cells). Raising the cap here
# means such a fallback still renders correctly instead of throwing.
pd.set_option("styler.render.max_elements", 2_000_000)

# --------------------------------------------------------------------------- #
# Configuration / Environment
# --------------------------------------------------------------------------- #
# Priority: st.secrets (if running on Streamlit Cloud / has a secrets.toml)
# falls back to plain environment variables. This keeps local dev (.env via
# os.environ, e.g. loaded through `python-dotenv` or exported in shell) and
# cloud deployment (st.secrets) both working without code changes.


def _get_config_value(key: str, default: str | None = None) -> str | None:
    """Fetch a config value from st.secrets first, then environment vars."""
    try:
        if key in st.secrets:
            return str(st.secrets[key])
    except Exception:
        # st.secrets raises if no secrets.toml exists at all -- that's fine,
        # we just fall through to environment variables.
        pass
    return os.environ.get(key, default)


DB_HOST = _get_config_value("DB_HOST", "localhost")
DB_PORT = _get_config_value("DB_PORT", "5432")
DB_NAME = _get_config_value("DB_NAME", "postgres")
DB_USER = _get_config_value("DB_USER", "postgres")
DB_PASSWORD = _get_config_value("DB_PASSWORD", "")
DB_SSLMODE = _get_config_value("DB_SSLMODE", "prefer")  # e.g. "require" for cloud DBs

# Allow a full DATABASE_URL to override the individual pieces above.
DATABASE_URL = _get_config_value("DATABASE_URL")


# --------------------------------------------------------------------------- #
# Database Engine (cached across reruns / sessions)
# --------------------------------------------------------------------------- #
@st.cache_resource(show_spinner="Connecting to database...")
def get_engine() -> Engine:
    """
    Build and cache a SQLAlchemy engine for the app's lifetime.

    Using @st.cache_resource ensures a single connection pool is reused
    across reruns instead of opening a new connection on every interaction.
    """
    if DATABASE_URL:
        url = DATABASE_URL
    else:
        url = (
            f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}"
            f"@{DB_HOST}:{DB_PORT}/{DB_NAME}?sslmode={DB_SSLMODE}"
        )

    engine = create_engine(
        url,
        pool_pre_ping=True,   # detect dead connections and recycle them
        pool_size=5,
        max_overflow=5,
        pool_recycle=1800,    # recycle connections every 30 minutes
    )
    # Fail fast if credentials/host are wrong, so we can show a clean error
    # at startup rather than on the first query the user runs.
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    return engine


def get_engine_safe() -> Engine | None:
    """Wrapper that turns connection failures into a clean st.error message."""
    try:
        return get_engine()
    except SQLAlchemyError as exc:
        st.error(
            "❌ Could not connect to the database. Please check your connection "
            f"settings.\n\nDetails: `{exc.__class__.__name__}: {exc}`"
        )
    except Exception as exc:  # noqa: BLE001 - surface any other startup issue
        st.error(f"❌ Unexpected error while connecting to the database: {exc}")
    return None


# --------------------------------------------------------------------------- #
# Shared DB/pivot engine, imported from db_core.py
# --------------------------------------------------------------------------- #
# `db_core.py` holds the framework-agnostic half of this app (schema
# introspection, query building, the Excel-style pivot/DPD-bucket/Field-
# Efficiency engine, Excel export, and auth helpers) so that this Streamlit
# app and the FastAPI service (`api.py`) always compute identical numbers
# from ONE source of truth instead of two copies that can silently drift
# apart. Every name below was diffed byte-for-byte against this file's
# previous, independently-tested implementation before being deleted here --
# nothing changed except where the code now physically lives.
#
# `db_core.get_engine()` is intentionally NOT imported/used here: it only
# reads plain environment variables, while this app also supports
# `st.secrets` (for Streamlit Cloud deployments) via `_get_config_value()`
# above -- that's a genuine Streamlit-specific behavior difference, not
# duplication, so `get_engine`/`get_engine_safe` stay defined locally.
import db_core as _core

# Pure functions / constants -- no caching needed, used exactly as-is.
classify_column = _core.classify_column
build_query = _core.build_query
_combine_group_stats = _core._combine_group_stats
_expand_date_fields = _core._expand_date_fields
_make_dims_cache = _core._make_dims_cache
_lookup_dims_value = _core._lookup_dims_value
_month_sort_key = _core._month_sort_key
_ordered_unique = _core._ordered_unique
_reorder_axis_chronologically = _core._reorder_axis_chronologically
_build_row_entries = _core._build_row_entries
_build_col_entries = _core._build_col_entries
_pretty_prefix = _core._pretty_prefix
_split_matrix_row_label = _core._split_matrix_row_label
_effective_col_level = _core._effective_col_level
add_dpd_buckets_to_excel_pivot = _core.add_dpd_buckets_to_excel_pivot
_date_field_leaf = _core._date_field_leaf
_prettify_date_leaf_axes = _core._prettify_date_leaf_axes
_clean_efficiency_column_label = _core._clean_efficiency_column_label
slice_field_efficiency_to_status = _core.slice_field_efficiency_to_status
build_pivot_table = _core.build_pivot_table
MONTH_NAMES = _core.MONTH_NAMES
CRORE = _core.CRORE
_is_employee_authorized = _core._is_employee_authorized
_get_password_hash = _core._get_password_hash
_account_exists = _core._account_exists
_create_account = _core._create_account
_verify_password = _core._verify_password
_touch_last_login = _core._touch_last_login
_log_audit_event = _core._log_audit_event
_too_many_recent_failures = _core._too_many_recent_failures

# Functions that were `@st.cache_data`/`@st.cache_resource`-wrapped here --
# re-apply the exact same decorator/ttl on top of db_core's plain version,
# so caching behavior is unchanged even though the logic now lives there.
list_tables = st.cache_data(ttl=300, show_spinner=False)(_core.list_tables)
get_columns = st.cache_data(ttl=300, show_spinner=False)(_core.get_columns)
get_distinct_values = st.cache_data(ttl=300, show_spinner=False)(_core.get_distinct_values)
get_distinct_values_filtered = st.cache_data(ttl=300, show_spinner=False)(_core.get_distinct_values_filtered)
get_available_years = st.cache_data(ttl=300, show_spinner=False)(_core.get_available_years)
get_available_year_months = st.cache_data(ttl=300, show_spinner=False)(_core.get_available_year_months)
run_query = st.cache_data(ttl=60, show_spinner=False)(_core.run_query)
fetch_pivot_source_data_multi = st.cache_data(ttl=600, show_spinner=False)(_core.fetch_pivot_source_data_multi)
build_excel_style_pivot = st.cache_data(ttl=300, show_spinner=False)(_core.build_excel_style_pivot)
dataframe_to_formatted_excel_bytes = st.cache_data(ttl=300, show_spinner=False)(_core.dataframe_to_formatted_excel_bytes)
build_field_efficiency_pivot = st.cache_data(ttl=300, show_spinner=False)(_core.build_field_efficiency_pivot)
ensure_auth_tables = st.cache_resource(show_spinner=False)(_core.ensure_auth_tables)



# --------------------------------------------------------------------------- #
# Master hierarchy grid (keep every hierarchy row, even with no data)
# --------------------------------------------------------------------------- #
# A plain GROUP BY only returns hierarchy combinations that have at least one
# transaction in the table, so e.g. an Area with no activity silently vanishes
# from the pivot. These helpers load a master hierarchy reference file
# (.txt/.csv/.tsv/.xlsx: zone, subzone, region, subregion, area, branch) and
# left-join the aggregated data onto it, so every master row appears -- with 0
# where it has no data -- BEFORE the subtotal tree is built (so subtotals and
# Grand Total stay consistent).
MASTER_HIERARCHY_DEFAULT_PATH = os.environ.get("MASTER_HIERARCHY_PATH", "master_hierarchy.txt")


def _norm_key(name: Any) -> str:
    """'Sub Zone' / 'sub_zone' / 'SUBZONE' all -> 'subzone'."""
    return re.sub(r"[^0-9a-z]+", "", str(name).strip().lower())


def _norm_val(v: Any) -> Any:
    return v.strip().upper() if isinstance(v, str) else v


@st.cache_data(show_spinner=False)
def load_master_hierarchy_grid(file_bytes: bytes, filename: str) -> pd.DataFrame:
    """Parse a master hierarchy file (.txt/.csv/.tsv delimiter auto-detected,
    or .xlsx/.xls) into `df_master`. Values are whitespace-trimmed, blank and
    duplicate rows dropped."""
    ext = filename.lower().rsplit(".", 1)[-1] if "." in filename else "txt"
    buf = io.BytesIO(file_bytes)
    if ext in ("xlsx", "xlsm", "xls", "xlsb"):
        df_master = pd.read_excel(buf, dtype=str)
    else:
        try:
            df_master = pd.read_csv(buf, sep=None, engine="python", dtype=str, encoding="utf-8-sig")
        except UnicodeDecodeError:
            buf.seek(0)
            df_master = pd.read_csv(buf, sep=None, engine="python", dtype=str, encoding="latin-1")
    df_master.columns = [str(c).strip() for c in df_master.columns]
    for c in df_master.columns:
        df_master[c] = df_master[c].astype("string").str.strip()
    return df_master.dropna(how="all").drop_duplicates().reset_index(drop=True)


def map_master_to_table_columns(df_master: pd.DataFrame, table_columns: list[str]) -> pd.DataFrame:
    """Rename master columns to the selected table's column names, matching
    ignoring case/spaces/underscores. Master columns with no match are
    dropped."""
    by_key = {_norm_key(c): c for c in table_columns}
    rename = {m: by_key[_norm_key(m)] for m in df_master.columns if _norm_key(m) in by_key}
    return df_master[list(rename)].rename(columns=rename)


MASTER_GRID_MAX_ROWS = 600_000


def _source_row_cols(row_cols: list[str], column_kind_map: dict[str, str]) -> list[str]:
    """Actual column names of the Rows fields inside the aggregated source
    (a date field is bucketed into '__<f>__month' + '__<f>__date')."""
    out: list[str] = []
    for f in row_cols:
        out += [f"__{f}__month", f"__{f}__date"] if column_kind_map.get(f) == "date" else [f]
    return out


def expand_source_with_master_grid(
    source_df: pd.DataFrame,
    df_master: pd.DataFrame,
    row_cols: list[str],
    column_kind_map: dict[str, str],
) -> tuple[pd.DataFrame, str | None]:
    """LEFT JOIN of the master grid onto the aggregated pivot source.

    Rows fields that exist in the master file (zone ... branch) are the
    "master fields". Any OTHER Rows field (e.g. program_tagging, which the
    master file doesn't have) is an "extra field": its values come from the
    data, and EVERY master combination is repeated under each extra value
    (each program gets the full hierarchy, zeros where it has no data).

    Every master/extra combination is also crossed with the column-side
    combinations already present in `source_df` (so zero rows appear under
    every column header). Stats are filled with 0; data rows missing from the
    master are kept, never dropped. Returns (dataframe, message) where a
    non-None message means the merge was skipped (or is worth showing)."""
    master_fields = [c for c in row_cols if c in df_master.columns and column_kind_map.get(c) != "date"]
    if source_df.empty or not master_fields:
        return source_df, "no Rows field is a master hierarchy column"
    extra_fields = [c for c in row_cols if c not in master_fields]
    src_row_cols = _source_row_cols(row_cols, column_kind_map)
    extra_src = [c for c in src_row_cols if c not in master_fields]
    stat_cols = [_core.STAT_SUM, _core.STAT_COUNT, _core.STAT_MIN, _core.STAT_MAX]
    col_side = [c for c in source_df.columns if c not in src_row_cols and c not in stat_cols]

    master_keys = df_master[master_fields].drop_duplicates().copy()
    src = source_df.copy()
    # Align spelling/case with the master so "East 1" and "EAST 1 " match.
    for c in master_fields:
        canon = {_norm_val(v): v for v in master_keys[c].dropna()}
        src[c] = src[c].map(lambda v, canon=canon: canon.get(_norm_val(v), v) if pd.notna(v) else v)
        master_keys[c] = master_keys[c].astype(object)
    key_cols = master_fields + extra_src + col_side
    src = (
        src.groupby(key_cols, dropna=False, as_index=False)
        .agg({_core.STAT_SUM: "sum", _core.STAT_COUNT: "sum", _core.STAT_MIN: "min", _core.STAT_MAX: "max"})
    )

    # Extra (non-master) row values as they exist in the data, x master rows.
    n_extra = src[extra_src].drop_duplicates().shape[0] if extra_src else 1
    n_cols = src[col_side].drop_duplicates().shape[0] if col_side else 1
    if (len(master_keys) + 0) * n_extra * n_cols > MASTER_GRID_MAX_ROWS:
        return source_df, (
            f"grid would be {len(master_keys) * n_extra * n_cols:,} rows "
            f"(master {len(master_keys):,} x {n_extra:,} extra-field combos x {n_cols:,} column combos) "
            "- too large; use fewer/lower-cardinality fields"
        )
    if extra_src:
        all_keys = src[extra_src].drop_duplicates().merge(master_keys, how="cross")
    else:
        all_keys = master_keys
    all_keys = pd.concat([all_keys, src[master_fields + extra_src]], ignore_index=True).drop_duplicates()
    grid = all_keys.merge(src[col_side].drop_duplicates(), how="cross") if col_side else all_keys
    merged = grid.merge(src, on=key_cols, how="left")
    merged[_core.STAT_SUM] = merged[_core.STAT_SUM].fillna(0.0)
    merged[_core.STAT_COUNT] = merged[_core.STAT_COUNT].fillna(0)
    # min/max stay NaN for empty groups on purpose: filling 0 would corrupt
    # the real minimum of every subtotal above them.
    return merged, None


# --------------------------------------------------------------------------- #
# Crore formatting helper
# --------------------------------------------------------------------------- #


def format_amount(value: float, in_crores: bool, decimals: int = 2) -> str:
    """Format a numeric total either as-is or converted to Crores (÷1,00,00,000)."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return "0.00 Cr" if in_crores else "0.00"
    if in_crores:
        return f"{value / CRORE:,.{decimals}f} Cr"
    return f"{value:,.{decimals}f}"


def series_to_crores(series: pd.Series) -> pd.Series:
    """Convert a numeric pandas Series to Crores."""
    return series / CRORE


@st.cache_data(ttl=300, show_spinner=False)
def get_monthly_summary(
    _engine: Engine,
    table_name: str,
    date_col: str,
    category_col: str | None = None,
    sum_cols: tuple[str, ...] = (),
) -> pd.DataFrame:
    """
    Aggregate row counts (and, optionally, SUM of one or more numeric columns)
    per calendar month based on `date_col`, optionally broken down by a second
    column (e.g. payment_mode). A record dated 01-03-2024 is grouped under
    March 2024 regardless of the day of month — this mirrors
    EXTRACT(MONTH FROM ...), same as the existing Month/Year filter above.

    Each requested sum column `col` shows up in the result as `sum_<col>`.
    """
    select_parts = [
        f'EXTRACT(YEAR FROM "{date_col}")::int AS yr',
        f'EXTRACT(MONTH FROM "{date_col}")::int AS mo',
    ]
    group_parts = ["yr", "mo"]

    if category_col:
        select_parts.append(f'"{category_col}"')
        group_parts.append(f'"{category_col}"')

    select_parts.append("COUNT(*) AS record_count")
    for col in sum_cols:
        select_parts.append(f'SUM("{col}") AS "sum_{col}"')

    query = text(
        f'SELECT {", ".join(select_parts)} '
        f'FROM "public"."{table_name}" '
        f'WHERE "{date_col}" IS NOT NULL '
        f'GROUP BY {", ".join(group_parts)} '
        f'ORDER BY yr, mo'
    )
    with _engine.connect() as conn:
        return pd.read_sql(query, conn)


# --------------------------------------------------------------------------- #
# Query builder
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# Excel-style 4-Quadrant Pivot Table engine
# --------------------------------------------------------------------------- #
PIVOT_AGG_FUNCS = ["sum", "mean", "count", "min", "max"]

# Column names used internally for the four pre-aggregated statistics that
# every pivot view (Summary Matrix, Field Efficiency Table, Chart, flat CSV)
# is built from. Carrying all four -- not just whichever agg_func is
# currently selected -- means switching the Values aggregation in the
# sidebar (sum -> mean -> count -> ...) never triggers a new database
# round-trip: it's just a different combination of these same four numbers,
# computed in pandas over an already-tiny, already-cached table.
STAT_SUM = "__stat_sum__"
STAT_COUNT = "__stat_count__"
STAT_MIN = "__stat_min__"
STAT_MAX = "__stat_max__"


_AGGRID_NUM_FORMATTERS: dict[str, "JsCode"] = {}
_aggrid_key_counter = itertools.count()


def _aggrid_num_formatter(num_fmt: str) -> "JsCode":
    """
    JS `valueFormatter` equivalent of the Python format strings already used
    across the app ("{:,.0f}", "{:,.2f}", "{:,.2f}%"). Cached per format
    string since JsCode objects are cheap to reuse and this can be called
    once per column.
    """
    if num_fmt in _AGGRID_NUM_FORMATTERS:
        return _AGGRID_NUM_FORMATTERS[num_fmt]
    if num_fmt == "{:,.0f}":
        decimals, suffix = 0, ""
    elif num_fmt == "{:,.2f}%":
        decimals, suffix = 2, "%"
    else:  # default "{:,.2f}"
        decimals, suffix = 2, ""
    js = JsCode(
        "function(params) {"
        " if (params.value === null || params.value === undefined) return '';"
        " return Number(params.value).toLocaleString(undefined, "
        f"{{minimumFractionDigits: {decimals}, maximumFractionDigits: {decimals}}}) + '{suffix}';"
        "}"
    )
    _AGGRID_NUM_FORMATTERS[num_fmt] = js
    return js


_AGGRID_GROUP_ROW_STYLE = JsCode(
    "function(params) {"
    " if (params.data && params.data.__is_group__) {"
    "   return { fontWeight: 'bold', backgroundColor: '#DCE6F1' };"
    " }"
    " return null;"
    "}"
)

_AGGRID_TOTAL_COL_CELL_STYLE = {"backgroundColor": "#F2F2F2"}


def _build_row_hierarchy_meta(
    display_df: pd.DataFrame,
    group_row_flags: list[bool],
) -> tuple[list[dict[str, Any]], str]:
    """
    Extracted from the original `_render_aggrid_matrix`: turns the Summary
    Matrix / Field Efficiency Table's index (built by `build_excel_style_pivot`,
    with its 4-space-per-level indentation + "↳ " leaf convention) into one
    AgGrid-ready record per row, WITHOUT touching Pandas Styler.

    Returns (records, row_label_field) where `records` already carries
    `__is_group__` (consumed by `_AGGRID_GROUP_ROW_STYLE` for bold + shading)
    and one numeric field per data column (`c0`, `c1`, ...), pre-converted to
    native Python floats/None so AgGrid never has to serialize numpy dtypes.
    """
    row_label_col = "__row__"
    n_rows, n_cols = display_df.shape
    field_names = [f"c{j}" for j in range(n_cols)]
    values = display_df.to_numpy(dtype="float64", na_value=np.nan)

    records: list[dict[str, Any]] = []
    for i in range(n_rows):
        raw_label = str(display_df.index[i])
        if raw_label == "Grand Total":
            depth, clean = 0, "Grand Total"
        else:
            depth, clean = _split_matrix_row_label(raw_label)
        is_group = bool(group_row_flags[i]) if i < len(group_row_flags) else False
        indent = "\u00A0" * (4 * depth)
        text = f"{indent}{clean}" if (is_group or depth == 0) else f"{indent}↳ {clean}"

        row: dict[str, Any] = {row_label_col: text, "__is_group__": is_group}
        for j, f in enumerate(field_names):
            v = values[i, j]
            row[f] = None if pd.isna(v) else float(v)
        records.append(row)

    return records, row_label_col


def _build_aggrid_column_defs(
    display_df: pd.DataFrame,
    total_col_flags: list[bool],
    num_fmt: str,
    row_label_col: str,
    row_axis_name: str | None,
) -> list[dict[str, Any]]:
    """
    Extracted from the original `_render_aggrid_matrix`: builds AgGrid's
    `columnDefs`, entirely in JS-side `valueFormatter`/`cellStyle` config --
    no Pandas Styler involved, so this never hits the styler element cap
    regardless of table size.

    - A MultiIndex column axis (2+ Columns fields) becomes AgGrid's native
      multi-level *grouped* column headers, built recursively so it works
      for any column depth, not just 2 levels.
    - Total columns get the same light-grey shading as the Excel export
      (`_AGGRID_TOTAL_COL_CELL_STYLE`, matching `_XL_TOTAL_COL_FILL`).
    - The Rows hierarchy stays ONE pinned "Row Labels" text column, indented
      per level, rather than one AgGrid column per hierarchy level: "one
      column per level" is AG Grid's Row Grouping / Tree Data mode, which is
      an AG Grid ENTERPRISE feature requiring a separate license key.
    """
    n_cols = display_df.shape[1]
    value_formatter = _aggrid_num_formatter(num_fmt)

    def _leaf_def(j: int) -> dict[str, Any]:
        header = str(display_df.columns[j][-1]) if isinstance(display_df.columns, pd.MultiIndex) else str(display_df.columns[j])
        d: dict[str, Any] = {
            "field": f"c{j}",
            "headerName": header,
            "type": "numericColumn",
            "valueFormatter": value_formatter,
            "sortable": True,
            "filter": "agNumberColumnFilter",
            "resizable": True,
            "minWidth": 115,
        }
        if j < len(total_col_flags) and total_col_flags[j]:
            d["cellStyle"] = _AGGRID_TOTAL_COL_CELL_STYLE
        return d

    if isinstance(display_df.columns, pd.MultiIndex):
        n_levels = display_df.columns.nlevels

        def _build_level(col_positions: list[int], level: int) -> list[dict[str, Any]]:
            if level == n_levels - 1:
                # Last level -> leaf columns themselves (their headerName is
                # already this level's value, via `_leaf_def`'s use of
                # `columns[j][-1]`) -- do NOT wrap it in one more group layer.
                return [_leaf_def(j) for j in col_positions]
            groups: dict[Any, list[int]] = {}
            order: list[Any] = []
            for j in col_positions:
                key = display_df.columns[j][level]
                if key not in groups:
                    groups[key] = []
                    order.append(key)
                groups[key].append(j)
            return [
                {"headerName": str(key), "children": _build_level(groups[key], level + 1), "marryChildren": True}
                for key in order
            ]

        column_defs = _build_level(list(range(n_cols)), 0)
    else:
        column_defs = [_leaf_def(j) for j in range(n_cols)]

    return [
        {
            "field": row_label_col,
            "headerName": row_axis_name or "Row Labels",
            "pinned": "left",
            "lockPinned": True,
            "sortable": True,
            "filter": "agTextColumnFilter",
            "minWidth": 260,
            "cellStyle": {"whiteSpace": "pre"},
        },
        *column_defs,
    ]


def display_virtualized_pivot(
    display_df: pd.DataFrame,
    group_row_flags: list[bool],
    total_col_flags: list[bool],
    num_fmt: str,
    grid_key: str | None = None,
    row_axis_name: str | None = None,
) -> None:
    """
    Render a Summary Matrix / Field Efficiency Table as a virtualized
    AgGrid instead of a fully-rendered static HTML table or a Pandas
    Styler pass. AgGrid only ever mounts DOM nodes for the rows currently
    scrolled into view, so a table with tens of thousands of rows no
    longer freezes the browser -- and never touches `.style.format()`, so
    it never hits the Styler element-count crash either.

    This is the single entry point every on-screen large-matrix render in
    the app should call; it composes `_build_row_hierarchy_meta` (rows) and
    `_build_aggrid_column_defs` (columns), which is what actually keeps the
    indentation, bold subtotal rows (`__is_group__`), and Total-column
    shading all computed natively in JS/AgGrid config rather than Pandas.
    """
    records, row_label_col = _build_row_hierarchy_meta(display_df, group_row_flags)
    full_column_defs = _build_aggrid_column_defs(display_df, total_col_flags, num_fmt, row_label_col, row_axis_name)

    grid_options = {
        "columnDefs": full_column_defs,
        "defaultColDef": {"resizable": True, "sortable": True, "filter": True},
        "getRowStyle": _AGGRID_GROUP_ROW_STYLE,
        "rowHeight": 30,
        "headerHeight": 32,
        "animateRows": False,
        "suppressFieldDotNotation": True,
    }

    n_rows = len(display_df)
    grid_height = min(700, 42 + n_rows * 30)
    AgGrid(
        pd.DataFrame.from_records(records),
        gridOptions=grid_options,
        height=max(grid_height, 150),
        theme="balham",
        allow_unsafe_jscode=True,
        fit_columns_on_grid_load=False,
        update_mode="NO_UPDATE",
        key=grid_key or f"aggrid_matrix_{next(_aggrid_key_counter)}",
    )


def _render_styled_pivot_matrix(
    display_df: pd.DataFrame,
    group_row_flags: list[bool],
    total_col_flags: list[bool],
    agg_func: str,
) -> None:
    """
    Render the Summary Matrix on screen as a virtualized AgGrid (see
    `display_virtualized_pivot`). Only the rows scrolled into view are ever
    mounted in the DOM, so this stays fast even with a very deep/large
    Rows hierarchy -- the earlier plain `st.dataframe` fallback (which
    deliberately dropped subtotal/Total shading to stay fast) is no longer
    needed: shading is back, and it's still fast.
    """
    num_fmt = "{:,.0f}" if agg_func == "count" else "{:,.2f}"
    try:
        display_virtualized_pivot(display_df, group_row_flags, total_col_flags, num_fmt)
    except Exception:
        # If AgGrid itself fails for any reason (bad install, odd dtype,
        # etc.), fall back to a plain, still-correct, unformatted table
        # rather than crashing the whole page.
        st.dataframe(display_df, use_container_width=True)


# One distinct, readable font color per Rows-hierarchy depth (e.g. Zone =
# level 0, Region = level 1, Sub-Zone = level 2, ...) -- cycles if a pivot
# somehow goes deeper than this. "Grand Total" and any row with no nesting
# always resolve to level 0. Used only for the Summary Matrix's single
# "Row Labels" column in the exported Excel file (see `_split_matrix_row_label`).


def render_excel_style_pivot_table(
    source_df: pd.DataFrame,
    row_cols: list[str],
    col_cols: list[str],
    value_col: str,
    agg_func: str,
    column_kind_map: dict[str, str],
    in_crores: bool,
    right_total_mode: str = "grand_total",
) -> tuple[pd.DataFrame, list[bool], list[bool]]:
    """Build the Excel-style nested pivot, render it (styled where possible),
    return (display_df, group_row_flags, total_col_flags) for CSV/Excel export."""
    display_df, group_row_flags, total_col_flags = build_excel_style_pivot(
        source_df, row_cols, col_cols, value_col, agg_func, column_kind_map, in_crores, right_total_mode
    )

    crore_suffix = " (in Cr)" if (in_crores and agg_func != "count") else ""
    st.markdown(f"**{agg_func.title()} of {value_col}{crore_suffix}**")
    _render_styled_pivot_matrix(display_df, group_row_flags, total_col_flags, agg_func)
    return display_df, group_row_flags, total_col_flags


def render_multi_value_pivot_table(
    source_df_by_value_col: dict[str, pd.DataFrame],
    row_cols: list[str],
    col_cols: list[str],
    value_cols: list[str],
    agg_func: str,
    column_kind_map: dict[str, str],
    in_crores: bool,
    right_total_mode: str = "grand_total",
    column_hierarchy_order: str = "value_then_col",
) -> tuple[pd.DataFrame, list[bool], list[bool]]:
    """
    Excel's "multiple Values fields" behaviour: build the IDENTICAL
    Excel-style pivot (same Rows/Columns/right_total_mode -- only the
    underlying numbers differ) once per Values column, using the exact same
    tested single-value engine, then place the results side by side with an
    extra outer header level naming each one (e.g. "Sum of EMI_Mar23" |
    "Sum of EMI_Apr23") -- exactly what Excel shows when you drag more than
    one field into the Values area. Every block is explicitly reindexed to
    the FIRST block's row order -- and, for safety, its column order too --
    before combining, so this is always a safe, purely side-by-side
    placement -- never an averaged, re-derived, or misaligned number.

    `column_hierarchy_order` picks which level is on the outside:
      - "value_then_col" (default) -> the original Excel-style layout: one
        "<Agg> of <value col>" block per Values field (e.g. per month) at
        the TOP level, with the Columns-field hierarchy (e.g. Stage)
        nested underneath each one.
      - "col_then_value" -> the mirror image: the Columns-field hierarchy
        (e.g. Stage) at the TOP level, with one "<Agg> of <value col>"
        column per Values field (e.g. per month) nested underneath each
        Stage -- so every month for STAGE_1 is grouped together, then
        STAGE_2, etc.
    """
    blocks: dict[str, pd.DataFrame] = {}
    per_block_total_col_flags: dict[str, list[bool]] = {}
    group_row_flags: list[bool] = []
    base_index: pd.Index | None = None
    base_columns: pd.Index | None = None

    for vc in value_cols:
        block_df, block_group_row_flags, block_total_col_flags = build_excel_style_pivot(
            source_df_by_value_col[vc], row_cols, col_cols, vc, agg_func, column_kind_map, in_crores, right_total_mode
        )
        if base_index is None:
            base_index = block_df.index
            group_row_flags = block_group_row_flags
        else:
            block_df = block_df.reindex(base_index).fillna(0.0)
        if base_columns is None:
            base_columns = block_df.columns
        else:
            # Guard against a Values column having a slightly different set
            # of Columns-field values present (e.g. one month missing a
            # Stage that another month has) -- keep every block on the
            # exact same column set/order so the swap below stays aligned.
            block_df = block_df.reindex(columns=base_columns).fillna(0.0)
        label = f"{agg_func.title()} of {vc}"
        blocks[label] = block_df
        per_block_total_col_flags[label] = block_total_col_flags

    if column_hierarchy_order == "col_then_value":
        # Swap: outer level = the Columns-field hierarchy (e.g. Stage),
        # inner level = one "<Agg> of <value col>" column per Values field
        # (e.g. per month) -- the mirror image of Excel's own default.
        first_label = f"{agg_func.title()} of {value_cols[0]}"
        swapped: dict[Any, pd.DataFrame] = {}
        tiled_total_col_flags: list[bool] = []
        for pos, col_key in enumerate(base_columns):
            sub = pd.DataFrame({
                f"{agg_func.title()} of {vc}": blocks[f"{agg_func.title()} of {vc}"][col_key]
                for vc in value_cols
            })
            swapped[col_key] = sub
            tiled_total_col_flags.extend(
                [per_block_total_col_flags[first_label][pos]] * len(value_cols)
            )
        display_df = pd.concat(swapped, axis=1)
    else:
        display_df = pd.concat(blocks, axis=1)
        tiled_total_col_flags = []
        for vc in value_cols:
            tiled_total_col_flags.extend(per_block_total_col_flags[f"{agg_func.title()} of {vc}"])

    crore_suffix = " (in Cr)" if (in_crores and agg_func != "count") else ""
    st.markdown(
        f"**{agg_func.title()} of {len(value_cols)} Values columns{crore_suffix}** "
        "— one column block per field, side by side"
    )
    _render_styled_pivot_matrix(display_df, group_row_flags, tiled_total_col_flags, agg_func)
    return display_df, group_row_flags, tiled_total_col_flags


# --------------------------------------------------------------------------- #
# General Field Efficiency Table: each cell as a % of the total across every
# OTHER value of a user-chosen field, holding every other selected Rows/
# Columns field fixed. Unlike a hardcoded "% of Stage" table, this works for
# *any* field the user points it at (a Rows field or a Columns field) — pick
# "staging_ecl" to get % of stage-group total per (Zone, Month); pick "zone"
# instead to get % of zone-group total per (Stage, Month); same formula.
# --------------------------------------------------------------------------- #


def _render_styled_efficiency_matrix(
    pivot_eff: pd.DataFrame, total_col_flags: list[bool], group_row_flags: list[bool] | None = None
) -> None:
    """
    Render the Field Efficiency Table on screen as a virtualized AgGrid
    (see `display_virtualized_pivot`) -- same reasoning as
    `_render_styled_pivot_matrix`. `group_row_flags` is optional here (some
    callers don't have a row tree to mark), and simply renders with no
    bolded/shaded rows when omitted.
    """
    try:
        display_virtualized_pivot(pivot_eff, group_row_flags or [], total_col_flags, "{:,.2f}%")
    except Exception:
        st.dataframe(pivot_eff, use_container_width=True)


_FLOW_RETENTION_ALIASES = {
    "flow": {"flow"},
    "normalised": {"normalised", "normalized"},
    "stabilized": {"stabilized", "stabilised"},
    "rollback": {"roll back", "rollback"},
}


def _flow_alias_key(text: str) -> str | None:
    """Map 'Flow'/'Normalised'/'Normalized'/'Stabilized'/'Stabilised'/'Roll Back'/
    'Rollback' (any case) to its canonical key; None for anything else."""
    stripped_lower = text.strip().lower()
    for key, names in _FLOW_RETENTION_ALIASES.items():
        if stripped_lower in names:
            return key
    return None


def _compute_flow_retention_from_rows(display_df: pd.DataFrame) -> pd.DataFrame:
    """Row-nested case: each row GROUP (e.g. an opening slab) has Flow /
    Normalised / Stabilized / (optional) Roll Back CHILD rows beneath it —
    see compute_flow_retention_table for the formula. Returns an empty
    DataFrame if no group has a Flow child row at all.

    Vectorized: no per-row .iloc[] access. We classify every label at once
    with pandas string ops, forward-fill the current group down onto its
    child rows, then split into up to four boolean-masked slices (one per
    Flow/Normalised/Stabilized/RollBack) and combine those slices with plain
    DataFrame arithmetic -- O(n) pandas/C operations instead of an O(n)
    Python loop building a fresh Series on every iteration.
    """
    # "Grand Total" rows are inert in the original row-walk (skipped
    # entirely, no effect on current_group) -- drop them up front.
    df2 = display_df[display_df.index != "Grand Total"]
    if df2.empty:
        return pd.DataFrame(columns=display_df.columns)

    labels = pd.Series(df2.index.astype(str).tolist())
    is_child = labels.str.contains("↳", na=False)

    # Header rows carry their own (stripped) name; forward-fill it onto the
    # child rows that follow, exactly like the sequential `current_group`.
    header_names = labels.where(~is_child).astype(object).str.strip()
    group_names = header_names.ffill()

    # Child rows: strip the "↳" marker and resolve to a canonical key.
    child_text = labels.where(is_child).astype(object).str.split("↳", n=1).str[-1].str.strip()
    keys = child_text.map(lambda s: _flow_alias_key(s) if isinstance(s, str) else None)

    valid = (is_child & keys.notna() & group_names.notna()).to_numpy()
    if not valid.any():
        return pd.DataFrame(columns=display_df.columns)

    sel = df2[valid]
    sel_groups = group_names.to_numpy()[valid]
    sel_keys = keys.to_numpy()[valid]

    def _slice_for(key: str) -> pd.DataFrame:
        key_mask = sel_keys == key
        if not key_mask.any():
            return pd.DataFrame(columns=display_df.columns)
        sub = sel[key_mask]
        sub_groups = sel_groups[key_mask]
        # Last-wins on a duplicate Flow/etc. row within the same group, same
        # as the dict-assignment overwrite in the original loop.
        keep_last = ~pd.Series(sub_groups).duplicated(keep="last").to_numpy()
        return pd.DataFrame(
            sub[keep_last].to_numpy(), index=sub_groups[keep_last], columns=display_df.columns
        )

    flow = _slice_for("flow")
    if flow.empty:
        return pd.DataFrame(columns=display_df.columns)
    normalised = _slice_for("normalised").reindex(flow.index).fillna(0.0)
    stabilized = _slice_for("stabilized").reindex(flow.index).fillna(0.0)
    rollback = _slice_for("rollback").reindex(flow.index).fillna(0.0)

    total = flow + normalised + stabilized + rollback
    pct_flow = (flow / total.replace(0, pd.NA)) * 100
    result = (100 - pct_flow).fillna(0.0)

    # Preserve original header-appearance order among groups that ended up
    # with a Flow row (same ordering guarantee as `group_order` before).
    group_order = list(dict.fromkeys(header_names.dropna().tolist()))
    ordered = [g for g in group_order if g in result.index]
    return result.loc[ordered]


def _compute_flow_retention_from_columns(display_df: pd.DataFrame) -> pd.DataFrame:
    """
    Column-nested case: Flow / Normalised / Stabilized / (optional) Roll Back
    are COLUMNS instead of rows (e.g. Columns = Slab > Flow/Normalised/...).
    Auto-detects which column level holds them (whichever level has the most
    distinct Flow/Normalised/Stabilized/RollBack matches), groups the OTHER
    levels together (e.g. one group per Slab), and returns one output column
    per group — same 100 - (Flow / (Flow+Normalised+Stabilized+RollBack) *
    100) formula, just transposed onto columns instead of rows. Existing
    '<x> Total' / 'Grand Total' columns are ignored; a fresh total is always
    computed from the four parts themselves. Returns an empty DataFrame if no
    level has a 'Flow' column at all.
    """
    columns = display_df.columns
    is_multi = isinstance(columns, pd.MultiIndex)
    n_levels = columns.nlevels if is_multi else 1
    tuples = [t if isinstance(t, tuple) else (t,) for t in columns]

    def _sel(t: tuple) -> Any:
        return t if is_multi else t[0]

    def _is_total_marker(v: Any) -> bool:
        return isinstance(v, str) and (v == "Grand Total" or v.endswith(" Total"))

    # Auto-detect which level holds Flow/Normalised/Stabilized/RollBack --
    # the level with the most distinct alias matches.
    best_level, best_count = None, 0
    for lvl in range(n_levels):
        matched = {
            _flow_alias_key(str(t[lvl])) for t in tuples
            if isinstance(t[lvl], str) and not _is_total_marker(t[lvl])
        }
        matched.discard(None)
        if len(matched) > best_count:
            best_level, best_count = lvl, len(matched)

    if best_level is None:
        return pd.DataFrame(index=display_df.index)

    def _group_key(t: tuple) -> tuple:
        return tuple(v for i, v in enumerate(t) if i != best_level)

    groups: dict[tuple, dict[str, tuple]] = {}
    group_order: list[tuple] = []
    for t in tuples:
        v = t[best_level]
        if not isinstance(v, str) or _is_total_marker(v):
            continue  # skip existing subtotal/Grand Total columns -- we rebuild our own total
        key = _flow_alias_key(v)
        if key is None:
            continue
        gk = _group_key(t)
        if gk not in groups:
            groups[gk] = {}
            group_order.append(gk)
        groups[gk][key] = t

    zeros = pd.Series(0.0, index=display_df.index)
    result_cols: dict[str, pd.Series] = {}
    for gk in group_order:
        parts = groups[gk]
        flow_tuple = parts.get("flow")
        if flow_tuple is None:
            continue  # no Flow column -> metric doesn't apply to this group
        flow = display_df[_sel(flow_tuple)]
        normalised = display_df[_sel(parts["normalised"])] if "normalised" in parts else zeros
        stabilized = display_df[_sel(parts["stabilized"])] if "stabilized" in parts else zeros
        rollback = display_df[_sel(parts["rollback"])] if "rollback" in parts else zeros
        total = flow + normalised + stabilized + rollback
        pct_flow = (flow / total.replace(0, pd.NA)) * 100
        result_cols[gk] = (100 - pct_flow).fillna(0.0)

    if not result_cols:
        return pd.DataFrame(index=display_df.index)

    # Keep the SAME stacked header structure as the Summary Matrix / Field
    # Efficiency table: one header level per remaining column level (e.g.
    # "LAP" on top, "1-29" beneath it, "Sum of March" beneath that) instead
    # of collapsing them into one flat "LAP / 1-29 / Sum of March" string.
    out = pd.concat(list(result_cols.values()), axis=1)
    out.index = display_df.index
    group_tuples = [tuple("" if v is None else str(v) for v in gk) for gk in result_cols]
    n_out_levels = len(group_tuples[0])
    if n_out_levels == 0:
        out.columns = ["Flow Retention %"]
    elif n_out_levels == 1:
        out.columns = pd.Index([t[0] for t in group_tuples])
    else:
        out.columns = pd.MultiIndex.from_tuples(group_tuples)
    return out


@st.cache_data(ttl=300, show_spinner=False)
def compute_flow_retention_table(display_df: pd.DataFrame) -> pd.DataFrame:
    """
    Alternate efficiency metric for Summary Matrices that break down into
    Flow / Normalised / Stabilized / (optional) Roll Back parts — as ROW
    children under a group (e.g. an opening-slab table) OR as COLUMNS
    (e.g. Columns = Slab > Flow/Normalised/...). For every group:

        100 - (Flow / (Flow + Normalised + Stabilized + RollBack) * 100)

    i.e. the % of that group's total that is NOT Flow. A missing part (e.g.
    no Roll Back for that slab) counts as 0; a group with no Flow part at
    all is skipped (the metric doesn't apply to it). Tries the row-nested
    layout first, falling back to the column-nested layout if rows didn't
    contain a 'Flow' anywhere; returns an empty DataFrame if neither does.
    """
    from_rows = _compute_flow_retention_from_rows(display_df)
    if not from_rows.empty:
        return from_rows
    return _compute_flow_retention_from_columns(display_df)


def render_field_efficiency_table(
    source_df: pd.DataFrame,
    row_cols: list[str],
    col_cols: list[str],
    normalize_field: str,
    value_col: str,
    agg_func: str,
    column_kind_map: dict[str, str],
) -> tuple[pd.DataFrame, list[bool], list[bool]]:
    """Build the general Field Efficiency table, render it, return
    (display_df, group_row_flags, total_col_flags) for CSV/Excel export."""
    pivot_eff, group_row_flags = build_field_efficiency_pivot(
        source_df, row_cols, col_cols, normalize_field, value_col, agg_func, column_kind_map
    )

    st.markdown(f"**{agg_func.title()} of {value_col} — % of `{normalize_field}` group total**")
    st.caption(
        f"Each cell = its value ÷ the sum across every value of **`{normalize_field}`** for that same "
        "combination of the other selected Rows/Columns fields — computed automatically for every "
        "row and column in the table, however many there are. Pick a different field above to "
        "normalize a different way (e.g. % across zones instead of % across stages). The **Total** "
        "row/column/corner are computed the same correct way — the underlying sum/count/min/max are "
        "combined first, then the % is derived — never by averaging the % cells."
    )

    total_col_flags = [False] * (pivot_eff.shape[1] - 1) + [True]
    _render_styled_efficiency_matrix(pivot_eff, total_col_flags, group_row_flags)
    return pivot_eff, group_row_flags, total_col_flags


def render_multi_value_field_efficiency_table(
    source_df_by_value_col: dict[str, pd.DataFrame],
    row_cols: list[str],
    col_cols: list[str],
    normalize_field: str,
    value_cols: list[str],
    agg_func: str,
    column_kind_map: dict[str, str],
    column_hierarchy_order: str = "value_then_col",
) -> tuple[pd.DataFrame, list[bool], list[bool]]:
    """
    Same idea as `render_multi_value_pivot_table`, applied to the Field
    Efficiency Table: build the IDENTICAL % table (same Rows/Columns/
    normalize_field -- only the underlying numbers differ) once per Values
    column, using the exact same tested single-value engine, then place the
    results side by side with an extra outer header level naming each one.
    Every block is reindexed to the FIRST block's row AND column order
    before combining, same safeguard as the Summary Matrix version -- so
    the FIRST block's group_row_flags (the row tree/order every other
    block was reindexed to match) is what's returned for CSV/Excel export.

    `column_hierarchy_order` is the exact same toggle used for the Summary
    Matrix -- "value_then_col" (default) keeps one "<Agg> of <value col>"
    block per Values field at the top, Columns-field values nested inside;
    "col_then_value" swaps it so every Columns-field value (e.g. each
    Stage) groups all its Values columns (e.g. every month) together.
    """
    blocks: dict[str, pd.DataFrame] = {}
    per_block_total_flags: dict[str, list[bool]] = {}
    base_index: pd.Index | None = None
    base_columns: pd.Index | None = None
    base_group_row_flags: list[bool] = []

    for vc in value_cols:
        block_df, block_group_row_flags = build_field_efficiency_pivot(
            source_df_by_value_col[vc], row_cols, col_cols, normalize_field, vc, agg_func, column_kind_map
        )
        if base_index is None:
            base_index = block_df.index
            base_group_row_flags = block_group_row_flags
        else:
            block_df = block_df.reindex(base_index).fillna(0.0)
        if base_columns is None:
            base_columns = block_df.columns
        else:
            block_df = block_df.reindex(columns=base_columns).fillna(0.0)
        label = f"{agg_func.title()} of {vc}"
        blocks[label] = block_df
        per_block_total_flags[label] = [False] * (block_df.shape[1] - 1) + [True]

    if column_hierarchy_order == "col_then_value":
        # Swap: outer level = the Columns-field hierarchy (e.g. Stage,
        # including its own "Total" column), inner level = one "<Agg> of
        # <value col>" column per Values field (e.g. per month).
        first_label = f"{agg_func.title()} of {value_cols[0]}"
        swapped: dict[Any, pd.DataFrame] = {}
        total_col_flags: list[bool] = []
        for pos, col_key in enumerate(base_columns):
            sub = pd.DataFrame({
                f"{agg_func.title()} of {vc}": blocks[f"{agg_func.title()} of {vc}"][col_key]
                for vc in value_cols
            })
            swapped[col_key] = sub
            total_col_flags.extend([per_block_total_flags[first_label][pos]] * len(value_cols))
        pivot_eff = pd.concat(swapped, axis=1)
    else:
        pivot_eff = pd.concat(blocks, axis=1)
        total_col_flags = []
        for vc in value_cols:
            total_col_flags.extend(per_block_total_flags[f"{agg_func.title()} of {vc}"])

    st.markdown(
        f"**{agg_func.title()} of {len(value_cols)} Values columns — % of `{normalize_field}` group total** "
        "— one column block per field, side by side"
    )
    st.caption(
        f"Each cell = its value ÷ the sum across every value of **`{normalize_field}`** for that same "
        "combination of the other selected Rows/Columns fields — computed separately for each Values "
        "column, then placed side by side. Never averaged or re-derived across columns."
    )
    _render_styled_efficiency_matrix(pivot_eff, total_col_flags, base_group_row_flags)
    return pivot_eff, base_group_row_flags, total_col_flags


# --------------------------------------------------------------------------- #
# Authentication & Authorization
# --------------------------------------------------------------------------- #
# Two tables, on purpose:
#   authorized_employees -- WHO is allowed to have an account at all (admin-managed)
#   app_users            -- the password hash for employees who created one
# Kept separate so access can be revoked (is_authorized = FALSE) without
# touching the password, and so "authorized" and "has an account" are two
# independently-true-or-false things.
_AUTH_SESSION_KEYS = ("auth_employee_code", "auth_employee_name", "auth_access_level")


def _render_login_form(engine: Engine) -> None:
    with st.form("login_form"):
        employee_code = st.text_input("Employee Code").strip().upper()
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login", use_container_width=True)

    if not submitted:
        return
    if not employee_code or not password:
        st.error("Please enter both your Employee Code and Password.")
        return
    if _too_many_recent_failures(engine, employee_code):
        st.error("Too many failed attempts for this employee code. Please try again in a few minutes.")
        return

    authorized, employee_name, access_level = _is_employee_authorized(engine, employee_code)
    password_hash = _get_password_hash(engine, employee_code)

    # Deliberately one generic error for every failure reason (not authorized /
    # no account yet / wrong password) -- so a login attempt never reveals
    # which employee codes exist, are authorized, or have registered.
    generic_error = "Invalid employee code or password."
    if not authorized or password_hash is None or not _verify_password(password, password_hash):
        _log_audit_event(engine, employee_code, "login_failure")
        st.error(generic_error)
        return

    _touch_last_login(engine, employee_code)
    _log_audit_event(engine, employee_code, "login_success")
    st.session_state["auth_employee_code"] = employee_code
    st.session_state["auth_employee_name"] = employee_name
    st.session_state["auth_access_level"] = access_level
    st.rerun()


def _render_create_account_form(engine: Engine) -> None:
    st.caption("Only employee codes explicitly authorized by your admin can create an account.")
    with st.form("create_account_form"):
        employee_code = st.text_input("Employee Code", key="create_code").strip().upper()
        password = st.text_input("Password", type="password", key="create_pw")
        confirm_password = st.text_input("Confirm Password", type="password", key="create_pw2")
        submitted = st.form_submit_button("Create Account", use_container_width=True)

    if not submitted:
        return
    if not employee_code or not password:
        st.error("Please fill in all fields.")
        return
    if password != confirm_password:
        st.error("Passwords do not match.")
        return
    if len(password) < 8:
        st.error("Please choose a password with at least 8 characters.")
        return

    authorized, employee_name, _access_level = _is_employee_authorized(engine, employee_code)
    if not authorized:
        st.error("Your employee code is not authorized to access this application. Please contact your administrator.")
        return
    if _account_exists(engine, employee_code):
        st.error("An account already exists for this employee code. Please log in instead.")
        return

    _create_account(engine, employee_code, password)
    st.success(f"Account created for {employee_name or employee_code}. You can now log in from the Login tab.")


def require_authentication(engine: Engine) -> None:
    """Gate the rest of the app behind login. Stops execution until authenticated."""
    if st.session_state.get("auth_employee_code"):
        return  # already logged in this session

    st.title("🔒 Employee Login")
    st.caption("This application is restricted to authorized department employees.")

    login_tab, create_tab = st.tabs(["Login", "Create Account"])
    with login_tab:
        _render_login_form(engine)
    with create_tab:
        _render_create_account_form(engine)

    st.stop()


def render_sidebar_identity(engine: Engine) -> None:
    """Small identity block + logout button, shown at the top of the sidebar."""
    name = st.session_state.get("auth_employee_name") or st.session_state["auth_employee_code"]
    level = st.session_state.get("auth_access_level", "user")
    st.markdown(f"👤 **{name}**  \n`{st.session_state['auth_employee_code']}` · {level}")
    if st.button("Logout", use_container_width=True):
        _log_audit_event(engine, st.session_state["auth_employee_code"], "logout")
        for key in _AUTH_SESSION_KEYS:
            st.session_state.pop(key, None)
        st.rerun()
    st.divider()


def render_admin_panel(engine: Engine) -> None:
    """Admin-only: manage the authorized-employee list. Caller must check role first."""
    st.subheader("🛡️ Authorized Employees")
    st.caption("Only employees listed here (and authorized) can create an account or log in.")

    query = text(
        "SELECT employee_code, employee_name, department, access_level, is_authorized "
        "FROM authorized_employees ORDER BY employee_code"
    )
    with engine.connect() as conn:
        employees_df = pd.read_sql(query, conn)
    st.dataframe(employees_df, use_container_width=True, height=300)

    st.markdown("#### ➕ Add an authorized employee")
    with st.form("admin_add_employee"):
        col1, col2 = st.columns(2)
        with col1:
            new_code = st.text_input("Employee Code").strip().upper()
            new_name = st.text_input("Employee Name").strip()
        with col2:
            new_dept = st.text_input("Department").strip()
            new_level = st.selectbox("Access Level", ["user", "analyst", "admin"])
        add_submitted = st.form_submit_button("Add Employee", use_container_width=True)

    if add_submitted:
        if not new_code or not new_name:
            st.error("Employee Code and Employee Name are required.")
        else:
            upsert_query = text(
                """
                INSERT INTO authorized_employees (employee_code, employee_name, department, access_level, is_authorized)
                VALUES (:code, :name, :dept, :level, TRUE)
                ON CONFLICT (employee_code) DO UPDATE
                SET employee_name = EXCLUDED.employee_name,
                    department = EXCLUDED.department,
                    access_level = EXCLUDED.access_level,
                    is_authorized = TRUE
                """
            )
            with engine.begin() as conn:
                conn.execute(upsert_query, {"code": new_code, "name": new_name, "dept": new_dept, "level": new_level})
            st.success(f"{new_code} added / re-authorized.")
            st.rerun()

    st.markdown("#### 🔁 Enable / disable an employee")
    if not employees_df.empty:
        toggle_code = st.selectbox("Employee Code", employees_df["employee_code"].tolist(), key="admin_toggle_code")
        current_row = employees_df.loc[employees_df["employee_code"] == toggle_code].iloc[0]
        col_a, col_b = st.columns(2)
        with col_a:
            if current_row["is_authorized"] and st.button("🚫 Disable", use_container_width=True):
                with engine.begin() as conn:
                    conn.execute(
                        text("UPDATE authorized_employees SET is_authorized = FALSE WHERE employee_code = :code"),
                        {"code": toggle_code},
                    )
                st.success(f"{toggle_code} disabled.")
                st.rerun()
        with col_b:
            if not current_row["is_authorized"] and st.button("✅ Re-enable", use_container_width=True):
                with engine.begin() as conn:
                    conn.execute(
                        text("UPDATE authorized_employees SET is_authorized = TRUE WHERE employee_code = :code"),
                        {"code": toggle_code},
                    )
                st.success(f"{toggle_code} re-enabled.")
                st.rerun()

    st.markdown("#### 📜 Recent login activity")
    audit_query = text(
        "SELECT employee_code, event, event_time FROM login_audit ORDER BY event_time DESC LIMIT 50"
    )
    with engine.connect() as conn:
        audit_df = pd.read_sql(audit_query, conn)
    st.dataframe(audit_df, use_container_width=True, height=250)


# --------------------------------------------------------------------------- #
# File Upload -> Database (admin / analyst only)
# --------------------------------------------------------------------------- #
# Ported from the standalone upload.py script, with one important fix: date
# columns are converted to real `date` objects (via .dt.date) and written
# with an explicit SQL DATE dtype, so Postgres stores them with no 00:00:00
# time component -- instead of drifting into a TIMESTAMP with a stray time.
_DATE_KEYWORDS = ("date", "month", "year", "time", "dt", "period")


def _format_date_like_header(col: Any) -> str:
    """Catch a date-like column header (real datetime, or date-looking string)
    and format it as e.g. 'March 23' before it gets snake_cased."""
    if hasattr(col, "strftime"):
        return col.strftime("%B %y")
    if isinstance(col, str) and ("/" in col or "-" in col or "00:00" in col):
        try:
            dt = pd.to_datetime(col, dayfirst=True)
            return dt.strftime("%B %y")
        except Exception:
            return col
    return str(col)


def _clean_column_name(name: str) -> str:
    name = str(name).strip().lower().replace(" ", "_")
    return re.sub(r"[^a-zA-Z0-9_]", "", name)


def _dedupe_columns(columns: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    result = []
    for col in columns:
        if col in seen:
            seen[col] += 1
            result.append(f"{col}_{seen[col]}")
        else:
            seen[col] = 0
            result.append(col)
    return result


def _excel_engine_for(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext == "xlsb":
        return "pyxlsb"
    if ext == "xls":
        return "xlrd"
    return "openpyxl"  # .xlsx / .xlsm


def process_uploaded_workbook(uploaded_file) -> tuple[pd.DataFrame, list[str]]:
    """
    Read every sheet, clean + snake_case headers (catching date-like headers
    first, e.g. a real Timestamp column header becomes 'march_23'), combine
    all sheets, dedupe column names, and convert any date/month/year/time/dt
    /period-named column into a true `date` (no time component).

    Returns (combined_dataframe, list_of_columns_converted_to_date).
    """
    engine_name = _excel_engine_for(uploaded_file.name)
    all_sheets = pd.read_excel(uploaded_file, sheet_name=None, engine=engine_name)

    cleaned_sheets = []
    for _sheet_name, sheet_df in all_sheets.items():
        sheet_df = sheet_df.copy()
        sheet_df.columns = [_format_date_like_header(col) for col in sheet_df.columns]
        sheet_df.columns = [_clean_column_name(col) for col in sheet_df.columns]
        cleaned_sheets.append(sheet_df)

    df = pd.concat(cleaned_sheets, ignore_index=True)
    df.columns = _dedupe_columns(list(df.columns))

    date_cols_converted: list[str] = []
    for col in df.columns:
        if any(kw in col.lower() for kw in _DATE_KEYWORDS):
            if pd.api.types.is_numeric_dtype(df[col]):
                # Excel's serial date epoch (day 0 = 30-Dec-1899)
                parsed = pd.to_datetime(df[col], unit="D", origin="1899-12-30", errors="coerce")
            else:
                # format="mixed" parses each value independently -- without it,
                # pandas guesses ONE format from the first value and silently
                # turns every differently-formatted date in the same column
                # (e.g. some rows with a trailing 00:00:00, some without) into
                # a blank instead of the real date.
                parsed = pd.to_datetime(df[col], dayfirst=True, format="mixed", errors="coerce")
            df[col] = parsed.dt.date  # strip the time component entirely -- no more 00:00:00
            date_cols_converted.append(col)

    return df, date_cols_converted


def render_upload_tab(engine: Engine) -> None:
    st.subheader("📤 Upload Data to Database")
    st.caption("Upload an Excel file — every sheet is cleaned, combined, and written as one table.")

    uploaded_file = st.file_uploader("Choose an Excel file", type=["xlsx", "xlsm", "xlsb", "xls"])
    if uploaded_file is not None:
        try:
            with st.spinner("Reading and cleaning the workbook..."):
                df, date_cols = process_uploaded_workbook(uploaded_file)
        except ImportError as exc:
            st.error(
                f"❌ Missing the Excel engine needed to read this file type ({exc}). "
                "Ask your admin to run `pip install pyxlsb xlrd` on the server for "
                ".xlsb / .xls support — .xlsx/.xlsm work out of the box."
            )
            return
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Failed to read the uploaded file: {exc}")
            return

        st.success(f"Loaded **{len(df):,}** rows and **{len(df.columns)}** columns from **{uploaded_file.name}**.")
        if date_cols:
            st.caption(f"🗓️ Cleaned as pure dates (no time component): {', '.join(date_cols)}")
        st.dataframe(df.head(20), use_container_width=True)

        default_table_name = _clean_column_name(uploaded_file.name.rsplit(".", 1)[0])
        col1, col2 = st.columns([2, 1])
        with col1:
            table_name = st.text_input("Destination table name", value=default_table_name)
        with col2:
            if_exists = st.selectbox("If table already exists", ["replace", "append", "fail"])

        if st.button("⬆️ Upload to Database", type="primary", use_container_width=True):
            table_name_clean = _clean_column_name(table_name)
            if not table_name_clean:
                st.error("Please enter a valid table name.")
            else:
                dtype_map = {col: sa_types.Date() for col in date_cols}
                try:
                    with st.spinner(f"Writing to table `{table_name_clean}`..."):
                        df.to_sql(
                            table_name_clean, engine, if_exists=if_exists, index=False,
                            chunksize=1000, dtype=dtype_map,
                        )
                    st.success(f"✅ Uploaded to table `{table_name_clean}` ({len(df):,} rows).")
                    list_tables.clear()
                except SQLAlchemyError as exc:
                    st.error(f"❌ Database error while uploading: {exc}")
                except Exception as exc:  # noqa: BLE001
                    st.error(f"❌ Unexpected error while uploading: {exc}")

    st.divider()
    st.markdown("#### 🗓️ Auto-generate `del_month_name` / `del_year`")
    st.caption(
        "Replaces the manual UPDATE query: pick a table and its date column, and this "
        "adds two columns — the month name only, and the year only — computed in PostgreSQL."
    )
    try:
        available_tables = list_tables(engine)
    except Exception as exc:  # noqa: BLE001
        st.error(f"❌ Could not list tables: {exc}")
        return
    if not available_tables:
        st.info("No tables found yet — upload a file above first.")
        return

    target_table = st.selectbox("Table", available_tables, key="del_cols_table")
    try:
        col_meta = get_columns(engine, target_table)
    except Exception as exc:  # noqa: BLE001
        st.error(f"❌ Could not list columns for `{target_table}`: {exc}")
        return

    date_like_cols = [c["name"] for c in col_meta if classify_column(c["type"]) == "date"]
    ref_col_options = date_like_cols if date_like_cols else [c["name"] for c in col_meta]
    if not date_like_cols:
        st.warning(
            "No columns in this table are stored as a real DATE/TIMESTAMP type yet — "
            "showing all columns, but this only works correctly on a genuine date column "
            "(exactly what a fresh upload above produces)."
        )
    ref_col = st.selectbox("Date column to derive month/year from", ref_col_options, key="del_cols_ref")

    if st.button("🧮 Generate del_month_name & del_year", use_container_width=True):
        try:
            with engine.begin() as conn:
                conn.execute(text(f'ALTER TABLE "{target_table}" ADD COLUMN IF NOT EXISTS del_month_name VARCHAR(20)'))
                conn.execute(text(f'ALTER TABLE "{target_table}" ADD COLUMN IF NOT EXISTS del_year INTEGER'))
                conn.execute(text(
                    f'UPDATE "{target_table}" SET '
                    f'del_month_name = TO_CHAR("{ref_col}"::date, \'FMMonth\'), '
                    f'del_year = EXTRACT(YEAR FROM "{ref_col}"::date)::INT'
                ))
            st.success(f"✅ `del_month_name` and `del_year` added to `{target_table}`, derived from `{ref_col}`.")
            get_columns.clear()
        except SQLAlchemyError as exc:
            st.error(f"❌ Database error: {exc}")
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Unexpected error: {exc}")


# --------------------------------------------------------------------------- #
# UI - Sidebar: connection status
# --------------------------------------------------------------------------- #
st.title("📊 Dynamic Database Explorer & Report Generator")
st.caption("Select a table, filter by any column, and export a custom report.")

engine = get_engine_safe()
if engine is None:
    st.info(
        "Set your database credentials as environment variables (or in "
        "`.streamlit/secrets.toml`) and reload the app. See the README / "
        "setup instructions for details."
    )
    st.stop()

ensure_auth_tables(engine)
require_authentication(engine)  # stops execution here until logged in

with st.sidebar:
    render_sidebar_identity(engine)
    st.header("⚙️ Configuration")
    st.success(f"Connected to **{DB_NAME}**@`{DB_HOST}`", icon="✅")

    try:
        tables = list_tables(engine)
    except SQLAlchemyError as exc:
        st.error(f"Failed to list tables: {exc}")
        st.stop()

    if not tables:
        st.warning("No tables found in the `public` schema.")
        st.stop()

    st.divider()
    selected_table = st.selectbox("📁 Select a table", options=tables, index=0)

# --------------------------------------------------------------------------- #
# Load column metadata for the selected table
# --------------------------------------------------------------------------- #
try:
    columns_meta = get_columns(engine, selected_table)
except SQLAlchemyError as exc:
    st.error(f"Failed to fetch columns for `{selected_table}`: {exc}")
    st.stop()

column_names = [c["name"] for c in columns_meta]
column_kind_map = {c["name"]: classify_column(c["type"]) for c in columns_meta}

with st.sidebar:
    st.divider()
    st.subheader("1️⃣ Reference (Filter) Column")
    ref_column = st.selectbox("Reference column", options=column_names, key="ref_col")

    detected_kind = column_kind_map.get(ref_column, "text")
    kind_override = st.radio(
        "Treat this column as",
        options=["Date/Timestamp", "Categorical/Text"],
        index=0 if detected_kind == "date" else 1,
        help="Auto-detected from the database column type; override if needed.",
    )
    ref_kind = "date" if kind_override == "Date/Timestamp" else "text"

    filter_payload: dict[str, Any] = {}

    if ref_kind == "date":
        granularity = st.radio(
            "Granularity",
            options=["Specific Date(s)", "Month/Year", "Year(s)"],
            key="granularity",
        )
        filter_payload["granularity"] = granularity

        if granularity == "Specific Date(s)":
            picked_dates = st.date_input(
                "Pick one or more dates",
                value=[],
                help="Click multiple dates; use the calendar's range/multi picker.",
            )
            # st.date_input returns a single date, a tuple, or a list depending
            # on interaction state -- normalize to a list of dates.
            if isinstance(picked_dates, (list, tuple)):
                filter_payload["dates"] = list(picked_dates)
            elif picked_dates:
                filter_payload["dates"] = [picked_dates]
            else:
                filter_payload["dates"] = []

        elif granularity == "Month/Year":
            try:
                available_ym = get_available_year_months(engine, selected_table, ref_column)
            except SQLAlchemyError as exc:
                st.error(f"Failed to fetch available months: {exc}")
                available_ym = []
            ym_labels = {f"{MONTH_NAMES[mo - 1]} {yr}": (yr, mo) for yr, mo in available_ym}
            selected_labels = st.multiselect("Select Month/Year", options=list(ym_labels.keys()))
            filter_payload["year_months"] = [ym_labels[lbl] for lbl in selected_labels]

        elif granularity == "Year(s)":
            try:
                available_years = get_available_years(engine, selected_table, ref_column)
            except SQLAlchemyError as exc:
                st.error(f"Failed to fetch available years: {exc}")
                available_years = []
            filter_payload["years"] = st.multiselect("Select Year(s)", options=available_years)

    else:
        try:
            distinct_values = get_distinct_values(engine, selected_table, ref_column)
        except SQLAlchemyError as exc:
            st.error(f"Failed to fetch distinct values: {exc}")
            distinct_values = []
        filter_payload["values"] = st.multiselect(
            f"Select value(s) of `{ref_column}`", options=distinct_values
        )

    st.divider()
    st.subheader("2️⃣ Target / Output Columns")
    output_candidates = [c for c in column_names if c != ref_column]
    output_columns = st.multiselect(
        "Select one or more output columns",
        options=output_candidates,
        default=output_candidates[:1] if output_candidates else [],
    )

    st.divider()
    st.subheader("3️⃣ Monthly Cumulative Summary (optional)")
    show_monthly_summary = st.checkbox(
        "Show monthly cumulative summary",
        value=False,
        help=(
            "Counts records per calendar month — a record dated 01-03-2024 is "
            "counted as a March record. Optionally break it down by another "
            "column, e.g. payment_mode (Cash / Cheque / DD)."
        ),
    )

    summary_date_col: str | None = None
    breakdown_col: str | None = None
    focus_year_months: list[tuple[int, int]] = []
    focus_years_summary: list[int] = []
    focus_categories: list[Any] = []
    sum_columns: list[str] = []
    show_in_crores: bool = False

    if show_monthly_summary:
        date_columns = [c for c in column_names if column_kind_map.get(c) == "date"]
        if not date_columns:
            st.warning("No date/timestamp columns found in this table — can't build a monthly summary.")
            show_monthly_summary = False
        else:
            default_date_col = ref_column if ref_kind == "date" and ref_column in date_columns else date_columns[0]
            summary_date_col = st.selectbox(
                "Date column to summarize by month",
                options=date_columns,
                index=date_columns.index(default_date_col),
                key=f"summary_date_col_{selected_table}",
            )

            breakdown_candidates = ["(None)"] + [c for c in column_names if c != summary_date_col]
            breakdown_choice = st.selectbox(
                "Breakdown by (optional) — e.g. payment_mode, or a numeric column like emi to sum it",
                options=breakdown_candidates,
                key=f"breakdown_choice_{selected_table}",
                help=(
                    "Pick a text/category column (e.g. payment_mode) to split the table "
                    "into groups. Pick a numeric column (e.g. emi) to total it instead — "
                    "numeric columns are never used to group by, since they "
                    "usually have far too many distinct values to group by."
                ),
            )

            if breakdown_choice == "(None)":
                breakdown_col = None
            elif column_kind_map.get(breakdown_choice) == "numeric":
                # Numeric columns can't sensibly be used to group the table (too many
                # distinct values -> hundreds of tiny groups). Treat this as
                # "sum this column" instead.
                breakdown_col = None
                st.caption(
                    f"ℹ️ `{breakdown_choice}` is numeric, so it'll be **summed**, not grouped by."
                )
                want_sum_choice = st.radio(
                    f"➕ Show the SUM of `{breakdown_choice}` for each month/year?",
                    options=["No", "Yes"],
                    index=0,
                    key=f"want_sum_{selected_table}_{breakdown_choice}",
                    horizontal=True,
                )
                if want_sum_choice == "Yes":
                    sum_columns = [breakdown_choice]
                    crores_choice = st.radio(
                        f"💰 Display the sum of `{breakdown_choice}` in Crores (÷ 1,00,00,000)?",
                        options=["No", "Yes"],
                        index=0,
                        key=f"crores_choice_{selected_table}_{breakdown_choice}",
                        horizontal=True,
                    )
                    show_in_crores = crores_choice == "Yes"
            else:
                # Categorical/text column -> normal group/color breakdown, same as before.
                breakdown_col = breakdown_choice

            try:
                available_ym_summary = get_available_year_months(engine, selected_table, summary_date_col)
            except SQLAlchemyError as exc:
                st.error(f"Failed to fetch available months: {exc}")
                available_ym_summary = []
            ym_labels_summary = {f"{MONTH_NAMES[mo - 1]} {yr}": (yr, mo) for yr, mo in available_ym_summary}
            focus_labels = st.multiselect(
                "Focus on specific month(s) — leave empty to see every month",
                options=list(ym_labels_summary.keys()),
                key=f"focus_months_{selected_table}_{summary_date_col}",
            )
            focus_year_months = [ym_labels_summary[lbl] for lbl in focus_labels]

            try:
                available_years_summary = get_available_years(engine, selected_table, summary_date_col)
            except SQLAlchemyError as exc:
                st.error(f"Failed to fetch available years: {exc}")
                available_years_summary = []
            focus_years_summary = st.multiselect(
                "Focus on specific year(s) — leave empty to see every year",
                options=available_years_summary,
                key=f"focus_years_summary_{selected_table}_{summary_date_col}",
            )
            if focus_year_months and focus_years_summary:
                st.caption(
                    "⚠️ Both a specific-month filter and a year filter are set — "
                    "the specific-month filter takes priority below. Clear it if you "
                    "just want the whole year(s) you picked."
                )

            if breakdown_col:
                try:
                    breakdown_values = get_distinct_values(engine, selected_table, breakdown_col)
                except SQLAlchemyError as exc:
                    st.error(f"Failed to fetch values for `{breakdown_col}`: {exc}")
                    breakdown_values = []
                focus_categories = st.multiselect(
                    f"Focus on specific {breakdown_col} value(s) — e.g. Cash — leave empty for all",
                    options=breakdown_values,
                    key=f"focus_categories_{selected_table}_{breakdown_col}",
                )

    st.divider()
    st.subheader("4️⃣ Summary table Analysis (optional)")
    show_pivot_table = st.checkbox(
        "Show monthly cumulative summary ",
        value=False,
        key=f"show_pivot_table_{selected_table}",
        help=(
            "Build a 4-quadrant Excel-style PivotTable: pick Filters, Rows, "
            "Columns, and a Value + aggregation, just like Excel's PivotTable."
        ),
    )

    pivot_filter_cols: list[str] = []
    pivot_filter_values: dict[str, list[Any]] = {}
    pivot_row_cols: list[str] = []
    pivot_col_cols: list[str] = []
    pivot_value_cols: list[str] = []
    pivot_agg_func: str = "sum"
    pivot_show_in_crores: bool = False
    pivot_right_total_mode: str = "grand_total"
    pivot_include_flat_export = False
    pivot_run_clicked = False
    pivot_is_built = st.session_state.get(f"pivot_built_{selected_table}", False)

    if show_pivot_table:
        numeric_cols = [c for c in column_names if column_kind_map.get(c) == "numeric"]

        st.markdown("**🔍 Filters**")
        st.caption(
            "Cascading — a field's own value list narrows down based on whatever you've already "
            "picked ABOVE it here, e.g. put Zone first, then Region only shows that zone's regions."
        )
        pivot_filter_cols = st.multiselect(
            "Column(s) to filter the dataset before pivoting",
            options=column_names,
            key=f"pivot_filter_cols_{selected_table}",
        )
        for fc in pivot_filter_cols:
            prior_filters = tuple(
                (other_fc, tuple(pivot_filter_values.get(other_fc, [])))
                for other_fc in pivot_filter_cols
                if other_fc != fc and pivot_filter_values.get(other_fc)
            )
            try:
                fc_values = get_distinct_values_filtered(engine, selected_table, fc, prior_filters)
            except SQLAlchemyError as exc:
                st.error(f"Failed to fetch values for `{fc}`: {exc}")
                fc_values = []
            pivot_filter_values[fc] = st.multiselect(
                f"↳ Value(s) of `{fc}` — leave empty to include all",
                options=fc_values,
                key=f"pivot_filter_vals_{selected_table}_{fc}",
            )

        st.markdown("**≡ Rows**")
        pivot_row_cols = st.multiselect(
            "Column(s) to group vertically (e.g. ZONE, BRANCH)",
            options=[c for c in column_names if c not in pivot_filter_cols],
            key=f"pivot_row_cols_{selected_table}",
        )

        st.markdown("**|||| Columns**")
        pivot_col_cols = st.multiselect(
            "Column(s) to split horizontally across headers (e.g. staging_ecl, STATUS)",
            options=[c for c in column_names if c not in pivot_row_cols],
            key=f"pivot_col_cols_{selected_table}",
        )

        # --- Master hierarchy grid --- #
        st.markdown("**🗂️ Master hierarchy**")
        _master_upload = st.file_uploader(
            "Master hierarchy file (.txt / .csv / .xlsx)",
            type=["txt", "csv", "tsv", "xlsx", "xls"],
            key="master_hierarchy_upload",
            help="zone, subzone, region, subregion, area, branch. If none is uploaded, "
                 f"`{MASTER_HIERARCHY_DEFAULT_PATH}` next to app.py is used when it exists.",
        )
        df_master_raw = None
        try:
            if _master_upload is not None:
                df_master_raw = load_master_hierarchy_grid(_master_upload.getvalue(), _master_upload.name)
            elif os.path.exists(MASTER_HIERARCHY_DEFAULT_PATH):
                with open(MASTER_HIERARCHY_DEFAULT_PATH, "rb") as _fh:
                    df_master_raw = load_master_hierarchy_grid(_fh.read(), MASTER_HIERARCHY_DEFAULT_PATH)
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Couldn't read the master hierarchy file: {exc}")
        df_master = map_master_to_table_columns(df_master_raw, column_names) if df_master_raw is not None else None

        include_master_grid = st.checkbox(
            "Include all master hierarchy rows from .txt file (display missing rows as 0)?",
            value=False,
            key=f"include_master_grid_{selected_table}",
            disabled=df_master is None or df_master.empty,
        )
        if df_master is None:
            st.caption("Upload a master file above to enable this option.")
        elif df_master.empty:
            st.warning("None of the master file's columns match this table's columns.")
        else:
            st.caption(f"{len(df_master):,} master rows · matched columns: {', '.join(df_master.columns)}")
            if include_master_grid and pivot_row_cols:
                _mf = [c for c in pivot_row_cols if c in df_master.columns]
                _xf = [c for c in pivot_row_cols if c not in df_master.columns]
                if not _mf:
                    st.info("Not applied: none of the selected **Rows** fields is a master hierarchy column.")
                elif _xf:
                    st.caption(f"Values for {', '.join(_xf)} come from the data; each gets every master row.")

        if len(pivot_col_cols) >= 2:
            deepest_label = pivot_col_cols[-1]
            outer_labels = ", ".join(pivot_col_cols[:-1])
            right_total_help = {
                "deepest_field_total": (
                    f"One '<value> Total' column per {deepest_label} (e.g. one per month), "
                    f"each summed across every {outer_labels} — the single overall Grand Total "
                    "column is dropped."
                ),
                "grand_total": "The original single 'Grand Total' column, summing everything together.",
                "both": (
                    f"The per-{deepest_label} Total columns, plus one overall Grand Total "
                    "at the very end."
                ),
            }
            pivot_right_total_mode = st.radio(
                f"↳ Rightmost total column(s) for `{deepest_label}`",
                options=["deepest_field_total", "grand_total", "both"],
                format_func=lambda k: {
                    "deepest_field_total": f"Per-{deepest_label} totals (new)",
                    "grand_total": "Single overall Grand Total (original)",
                    "both": "Both",
                }[k],
                index=0,
                key=f"pivot_right_total_mode_{selected_table}",
                help=right_total_help["deepest_field_total"],
            )
            st.caption(right_total_help[pivot_right_total_mode])
        else:
            pivot_right_total_mode = "grand_total"

        st.markdown("**∑ Values & Aggregation**")
        pivot_value_cols = st.multiselect(
            "Column(s) to aggregate — pick more than one to get each as its own set of "
            "columns (e.g. \"Sum of EMI_Mar23\", \"Sum of EMI_Apr23\"), just like Excel's "
            "multiple Values fields",
            options=column_names,
            key=f"pivot_value_cols_{selected_table}",
        )
        pivot_agg_func = st.selectbox(
            "Aggregation function (applied to every Values column picked above)",
            options=PIVOT_AGG_FUNCS,
            key=f"pivot_agg_func_{selected_table}",
        )

        if pivot_value_cols and pivot_agg_func != "count":
            crores_pivot_choice = st.radio(
                "💰 Display value(s) in Crores (÷ 1,00,00,000) in the Summary Table?",
                options=["No", "Yes"],
                index=0,
                key=f"pivot_crores_{selected_table}",
                horizontal=True,
            )
            pivot_show_in_crores = crores_pivot_choice == "Yes"

        pivot_column_hierarchy_order = "value_then_col"
        if len(pivot_value_cols) >= 2 and pivot_col_cols:
            hierarchy_labels = {
                "value_then_col": f"{pivot_value_cols[0]} → {pivot_col_cols[0]}",
                "col_then_value": f"{pivot_col_cols[0]} → {pivot_value_cols[0]}",
            }
            pivot_column_hierarchy_order = st.radio(
                "Column Hierarchy Order",
                options=["value_then_col", "col_then_value"],
                format_func=lambda k: {
                    "value_then_col": f"Values → Columns  (e.g. {hierarchy_labels['value_then_col']})",
                    "col_then_value": f"Columns → Values  (e.g. {hierarchy_labels['col_then_value']})",
                }[k],
                index=0,
                key=f"pivot_column_hierarchy_order_{selected_table}",
                horizontal=True,
                help=(
                    "With 2+ Values columns (e.g. months) and 1+ Columns field (e.g. Stage), "
                    "choose which one sits on the outer header level. 'Values → Columns' is the "
                    "original Excel-style layout; 'Columns → Values' swaps it so the Columns "
                    "field groups everything (all months for STAGE_3 together, then STAGE_2, "
                    "etc.)."
                ),
            )

        st.caption("A Grand Total row is always added. Column totals follow your choice above (if shown).")
        pivot_include_flat_export = st.checkbox(
            "Prepare the additional flat Pivot Excel download",
            value=False,
            key=f"pivot_flat_export_{selected_table}",
            help="The flat export is separate from the styled Summary Matrix and is only built when requested.",
        )
        pivot_run_clicked = st.button(
            "🧮 Build Summary", type="primary", use_container_width=True, key=f"pivot_run_{selected_table}"
        )
        if pivot_run_clicked:
            # A button's True value only lasts for the one rerun it was clicked
            # on — the very next rerun (e.g. touching a widget in the ratio
            # calculator below, or tweaking Rows/Columns) it reports False
            # again. Persist "this table's pivot has been built" separately so
            # the whole Summary Table doesn't vanish and reappear stale on
            # every unrelated interaction; it now stays live and always
            # reflects the *current* Rows/Columns/Values choices.
            st.session_state[f"pivot_built_{selected_table}"] = True
        pivot_is_built = st.session_state.get(f"pivot_built_{selected_table}", False)

    st.divider()
    run_clicked = st.button("🚀 Generate Report", type="primary", use_container_width=True)

# --------------------------------------------------------------------------- #
# Main UI - Tabs Layout
# --------------------------------------------------------------------------- #
_access_level = st.session_state.get("auth_access_level", "user")
_can_use_sql_tab = _access_level in ("admin", "analyst")

_tab_labels = ["📊 Dynamic Report Builder", "🧮 Summary Table"]
if _can_use_sql_tab:
    _tab_labels.append("📤 Upload Data")
    _tab_labels.append("🧑‍💻 Custom SQL Query")
if _access_level == "admin":
    _tab_labels.append("🛡️ Admin")

_tabs = st.tabs(_tab_labels)
tab_report, tab_pivot = _tabs[0], _tabs[1]
tab_upload = _tabs[2] if _can_use_sql_tab else None
tab_sql = _tabs[3] if _can_use_sql_tab else None
tab_admin = _tabs[-1] if _access_level == "admin" else None

if tab_upload is not None:
    with tab_upload:
        render_upload_tab(engine)

if tab_admin is not None:
    with tab_admin:
        render_admin_panel(engine)

with tab_report:
    # --------------------------------------------------------------------------- #
    # Monthly Cumulative Summary (independent of the report section below)
    # --------------------------------------------------------------------------- #
    if show_monthly_summary and summary_date_col:
        st.subheader("🗓️ Monthly Cumulative Summary")
        st.caption(
            f"Every record is counted under the calendar month of `{summary_date_col}` "
            "— e.g. a record dated 01-03-2024 is counted as a **March** record, regardless of the day."
        )

        try:
            with st.spinner("Building monthly summary..."):
                summary_df = get_monthly_summary(
                    engine, selected_table, summary_date_col, breakdown_col, tuple(sum_columns)
                )
        except SQLAlchemyError as exc:
            st.error(f"❌ Failed to build monthly summary: {exc}")
            summary_df = pd.DataFrame()
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Unexpected error while building monthly summary: {exc}")
            summary_df = pd.DataFrame()

        if summary_df.empty:
            st.info("No data available to summarize for this date column.")
        else:
            summary_df["month_label"] = summary_df.apply(
                lambda r: f"{MONTH_NAMES[int(r['mo']) - 1]} {int(r['yr'])}", axis=1
            )
            summary_df = summary_df.sort_values(["yr", "mo"])

            # Apply optional focus filters chosen in the sidebar.
            # If specific month(s) are picked, that's the most precise filter and wins.
            # Otherwise, fall back to year-only focus so picking "2023" here also
            # narrows this monthly view down to just 2023 (previously this only
            # affected the Yearly section below, which made the monthly chart/table/
            # CSV look "unfiltered" even after picking a year).
            display_df = summary_df.copy()
            if focus_year_months:
                focus_set = {(int(yr), int(mo)) for yr, mo in focus_year_months}
                display_df = display_df[
                    display_df.apply(lambda r: (int(r["yr"]), int(r["mo"])) in focus_set, axis=1)
                ]
            elif focus_years_summary:
                focus_years_set = {int(y) for y in focus_years_summary}
                display_df = display_df[display_df["yr"].astype(int).isin(focus_years_set)]
            if breakdown_col and focus_categories:
                display_df = display_df[display_df[breakdown_col].isin(focus_categories)]

            if display_df.empty:
                st.warning(
                    "No records match the selected month/category focus. "
                    f"Active filters — Month(s): {focus_labels or 'none'}, "
                    f"Year(s): {focus_years_summary or 'none'}, "
                    f"{breakdown_col or 'category'}: {focus_categories or 'none'}. "
                    "Clear one of these in the sidebar to see results."
                )
            elif breakdown_col:

                # --- Excel-style pivot: rows = month, columns = category ---
                pivot_df = display_df.pivot_table(
                    index="month_label",
                    columns=breakdown_col,
                    values="record_count",
                    aggfunc="sum",
                    fill_value=0,
                    margins=True,
                    margins_name="Total",
                )
                month_order = [
                    m for m in display_df.sort_values(["yr", "mo"])["month_label"].unique() if m in pivot_df.index
                ]
                if "Total" in pivot_df.index:
                    month_order.append("Total")
                pivot_df = pivot_df.reindex(month_order)
                st.dataframe(pivot_df, use_container_width=True)

                summary_csv_buffer = io.StringIO()
                pivot_df.to_csv(summary_csv_buffer)
                st.download_button(
                    "⬇️ Download Monthly Breakdown CSV",
                    data=summary_csv_buffer.getvalue(),
                    file_name=f"{selected_table}_monthly_{breakdown_col}_summary.csv",
                    mime="text/csv",
                    key="download_monthly_breakdown",
                )

                # --- Plain row-by-row data (Month | category | Count) ---------
                with st.expander("📋 View all rows (Month × " + breakdown_col + ")", expanded=False):
                    flat_df = display_df[["month_label", breakdown_col, "record_count"]].rename(
                        columns={"month_label": "Month", "record_count": "Count"}
                    )
                    st.dataframe(flat_df, use_container_width=True, hide_index=True)
                    flat_csv_buffer = io.StringIO()
                    flat_df.to_csv(flat_csv_buffer, index=False)
                    st.download_button(
                        "⬇️ Download Filtered Rows CSV",
                        data=flat_csv_buffer.getvalue(),
                        file_name=f"{selected_table}_monthly_{breakdown_col}_rows.csv",
                        mime="text/csv",
                        key="download_monthly_breakdown_rows",
                    )
            else:
                # --- Simple month-over-month comparison (with value labels) ---

                if focus_year_months:
                    cols = st.columns(min(len(display_df), 4) or 1)
                    for i, (_, row) in enumerate(display_df.iterrows()):
                        cols[i % len(cols)].metric(row["month_label"], f"{int(row['record_count']):,}")

                st.dataframe(
                    display_df[["month_label", "record_count"]].rename(
                        columns={"month_label": "Month", "record_count": "Count"}
                    ),
                    use_container_width=True,
                    hide_index=True,
                )

                summary_csv_buffer = io.StringIO()
                display_df[["month_label", "record_count"]].to_csv(summary_csv_buffer, index=False)
                st.download_button(
                    "⬇️ Download Monthly Summary CSV",
                    data=summary_csv_buffer.getvalue(),
                    file_name=f"{selected_table}_monthly_summary.csv",
                    mime="text/csv",
                    key="download_monthly_summary",
                )

            # --- Optional SUM columns (e.g. "emi") per month ------------------- #
            if not display_df.empty and sum_columns:
                unit_note = " (shown in Crores)" if show_in_crores else ""
                for sc in sum_columns:
                    sum_field = f"sum_{sc}"
                    if sum_field not in display_df.columns:
                        continue

                    st.markdown(f"#### 💵 Sum of `{sc}` per month{unit_note}")

                    if breakdown_col:

                        sum_pivot_df = display_df.pivot_table(
                            index="month_label",
                            columns=breakdown_col,
                            values=sum_field,
                            aggfunc="sum",
                            fill_value=0,
                            margins=True,
                            margins_name="Total",
                        )
                        sum_pivot_df = sum_pivot_df.reindex(
                            [m for m in month_order if m in sum_pivot_df.index]
                        )
                        sum_pivot_view = (
                            sum_pivot_df.div(CRORE) if show_in_crores else sum_pivot_df
                        ).round(2)
                        st.dataframe(sum_pivot_view, use_container_width=True)
                        if show_in_crores:
                            st.caption("Table above is in Crores. Downloaded CSV keeps raw (non-Crore) values.")

                        sum_csv_buffer = io.StringIO()
                        sum_pivot_df.to_csv(sum_csv_buffer)  # always raw values in CSV
                        st.download_button(
                            f"⬇️ Download Monthly Sum({sc}) Breakdown CSV",
                            data=sum_csv_buffer.getvalue(),
                            file_name=f"{selected_table}_monthly_sum_{sc}_{breakdown_col}.csv",
                            mime="text/csv",
                            key=f"download_monthly_sum_{sc}_breakdown",
                        )
                    else:

                        if focus_year_months:
                            m_cols = st.columns(min(len(display_df), 4) or 1)
                            for i, (_, row) in enumerate(display_df.iterrows()):
                                m_cols[i % len(m_cols)].metric(
                                    row["month_label"], format_amount(row[sum_field], show_in_crores)
                                )

                        sum_table_df = display_df[["month_label", sum_field]].rename(
                            columns={"month_label": "Month", sum_field: f"Sum({sc})"}
                        )
                        table_view = sum_table_df.copy()
                        if show_in_crores:
                            table_view[f"Sum({sc}) [Cr]"] = series_to_crores(table_view[f"Sum({sc})"]).round(2)
                            table_view = table_view.drop(columns=[f"Sum({sc})"])
                        st.dataframe(table_view, use_container_width=True, hide_index=True)

                        sum_csv_buffer = io.StringIO()
                        sum_table_df.to_csv(sum_csv_buffer, index=False)  # raw values in CSV
                        st.download_button(
                            f"⬇️ Download Monthly Sum({sc}) CSV",
                            data=sum_csv_buffer.getvalue(),
                            file_name=f"{selected_table}_monthly_sum_{sc}.csv",
                            mime="text/csv",
                            key=f"download_monthly_sum_{sc}",
                        )
                    st.divider()
        st.divider()

        # --------------------------------------------------------------------------- #
        # Yearly Cumulative Summary — same data, rolled up to 2023 / 2024 / 2025 ...
        # --------------------------------------------------------------------------- #
        st.subheader("📅 Yearly Cumulative Summary")
        st.caption(
            f"Same data as above, rolled up to the calendar year of `{summary_date_col}` "
            "(e.g. 2023, 2024, 2025)."
        )

        group_cols = ["yr"] + ([breakdown_col] if breakdown_col else [])
        yearly_agg_cols = ["record_count"] + [f"sum_{sc}" for sc in sum_columns if f"sum_{sc}" in summary_df.columns]
        yearly_df = summary_df.groupby(group_cols, as_index=False)[yearly_agg_cols].sum()
        yearly_df["year_label"] = yearly_df["yr"].astype(int).astype(str)
        yearly_df = yearly_df.sort_values("yr")

        yearly_display_df = yearly_df.copy()
        if focus_years_summary:
            focus_years_set = {int(y) for y in focus_years_summary}
            yearly_display_df = yearly_display_df[yearly_display_df["yr"].astype(int).isin(focus_years_set)]
        if breakdown_col and focus_categories:
            yearly_display_df = yearly_display_df[yearly_display_df[breakdown_col].isin(focus_categories)]

        if yearly_display_df.empty:
            st.warning(
                "No records match the selected year/category focus. "
                f"Active filters — Year(s): {focus_years_summary or 'none'}, "
                f"{breakdown_col or 'category'}: {focus_categories or 'none'}. "
                "Clear one of these in the sidebar to see results."
            )
        elif breakdown_col:

            yearly_pivot_df = yearly_display_df.pivot_table(
                index="year_label",
                columns=breakdown_col,
                values="record_count",
                aggfunc="sum",
                fill_value=0,
                margins=True,
                margins_name="Total",
            )
            year_order = [
                y for y in yearly_display_df.sort_values("yr")["year_label"].unique() if y in yearly_pivot_df.index
            ]
            if "Total" in yearly_pivot_df.index:
                year_order.append("Total")
            yearly_pivot_df = yearly_pivot_df.reindex(year_order)
            st.dataframe(yearly_pivot_df, use_container_width=True)

            yearly_csv_buffer = io.StringIO()
            yearly_pivot_df.to_csv(yearly_csv_buffer)
            st.download_button(
                "⬇️ Download Yearly Breakdown CSV",
                data=yearly_csv_buffer.getvalue(),
                file_name=f"{selected_table}_yearly_{breakdown_col}_summary.csv",
                mime="text/csv",
                key="download_yearly_breakdown",
            )

            # --- Plain row-by-row data (Year | category | Count) -------------
            with st.expander("📋 View all rows (Year × " + breakdown_col + ")", expanded=False):
                yearly_flat_df = yearly_display_df[["year_label", breakdown_col, "record_count"]].rename(
                    columns={"year_label": "Year", "record_count": "Count"}
                )
                st.dataframe(yearly_flat_df, use_container_width=True, hide_index=True)
                yearly_flat_csv_buffer = io.StringIO()
                yearly_flat_df.to_csv(yearly_flat_csv_buffer, index=False)
                st.download_button(
                    "⬇️ Download Filtered Rows CSV",
                    data=yearly_flat_csv_buffer.getvalue(),
                    file_name=f"{selected_table}_yearly_{breakdown_col}_rows.csv",
                    mime="text/csv",
                    key="download_yearly_breakdown_rows",
                )
        else:

            if focus_years_summary:
                cols = st.columns(min(len(yearly_display_df), 4) or 1)
                for i, (_, row) in enumerate(yearly_display_df.iterrows()):
                    cols[i % len(cols)].metric(row["year_label"], f"{int(row['record_count']):,}")

            st.dataframe(
                yearly_display_df[["year_label", "record_count"]].rename(
                    columns={"year_label": "Year", "record_count": "Count"}
                ),
                use_container_width=True,
                hide_index=True,
            )

            yearly_csv_buffer = io.StringIO()
            yearly_display_df[["year_label", "record_count"]].to_csv(yearly_csv_buffer, index=False)
            st.download_button(
                "⬇️ Download Yearly Summary CSV",
                data=yearly_csv_buffer.getvalue(),
                file_name=f"{selected_table}_yearly_summary.csv",
                mime="text/csv",
                key="download_yearly_summary",
            )

        # --- Optional SUM columns (e.g. "emi") per year ------------------- #
        if not yearly_display_df.empty and sum_columns:
            unit_note = " (shown in Crores)" if show_in_crores else ""
            for sc in sum_columns:
                sum_field = f"sum_{sc}"
                if sum_field not in yearly_display_df.columns:
                    continue

                st.markdown(f"#### 💵 Sum of `{sc}` per year{unit_note}")

                if breakdown_col:

                    yearly_sum_pivot_df = yearly_display_df.pivot_table(
                        index="year_label",
                        columns=breakdown_col,
                        values=sum_field,
                        aggfunc="sum",
                        fill_value=0,
                        margins=True,
                        margins_name="Total",
                    )
                    yearly_sum_pivot_df = yearly_sum_pivot_df.reindex(
                        [y for y in year_order if y in yearly_sum_pivot_df.index]
                    )
                    yearly_sum_pivot_view = (
                        yearly_sum_pivot_df.div(CRORE) if show_in_crores else yearly_sum_pivot_df
                    ).round(2)
                    st.dataframe(yearly_sum_pivot_view, use_container_width=True)
                    if show_in_crores:
                        st.caption("Table above is in Crores. Downloaded CSV keeps raw (non-Crore) values.")

                    yearly_sum_csv_buffer = io.StringIO()
                    yearly_sum_pivot_df.to_csv(yearly_sum_csv_buffer)  # raw values
                    st.download_button(
                        f"⬇️ Download Yearly Sum({sc}) Breakdown CSV",
                        data=yearly_sum_csv_buffer.getvalue(),
                        file_name=f"{selected_table}_yearly_sum_{sc}_{breakdown_col}.csv",
                        mime="text/csv",
                        key=f"download_yearly_sum_{sc}_breakdown",
                    )
                else:

                    if focus_years_summary:
                        y_cols = st.columns(min(len(yearly_display_df), 4) or 1)
                        for i, (_, row) in enumerate(yearly_display_df.iterrows()):
                            y_cols[i % len(y_cols)].metric(
                                row["year_label"], format_amount(row[sum_field], show_in_crores)
                            )

                    yearly_sum_table_df = yearly_display_df[["year_label", sum_field]].rename(
                        columns={"year_label": "Year", sum_field: f"Sum({sc})"}
                    )
                    yearly_table_view = yearly_sum_table_df.copy()
                    if show_in_crores:
                        yearly_table_view[f"Sum({sc}) [Cr]"] = series_to_crores(
                            yearly_table_view[f"Sum({sc})"]
                        ).round(2)
                        yearly_table_view = yearly_table_view.drop(columns=[f"Sum({sc})"])
                    st.dataframe(yearly_table_view, use_container_width=True, hide_index=True)

                    yearly_sum_csv_buffer = io.StringIO()
                    yearly_sum_table_df.to_csv(yearly_sum_csv_buffer, index=False)  # raw values
                    st.download_button(
                        f"⬇️ Download Yearly Sum({sc}) CSV",
                        data=yearly_sum_csv_buffer.getvalue(),
                        file_name=f"{selected_table}_yearly_sum_{sc}.csv",
                        mime="text/csv",
                        key=f"download_yearly_sum_{sc}",
                    )
                st.divider()
        st.divider()

    # --------------------------------------------------------------------------- #
    # Main panel - results
    # --------------------------------------------------------------------------- #
    if not output_columns:
        st.info("👈 Select at least one output column in the sidebar to build a report.")
    elif not run_clicked:
        st.info("👈 Configure your filters and click **Generate Report** to run the query.")
    else:
        query, params = build_query(selected_table, ref_column, output_columns, ref_kind, filter_payload)

        with st.expander("🔍 View generated SQL", expanded=False):
            st.code(query, language="sql")
            if params:
                st.caption("Parameters:")
                st.json({k: str(v) for k, v in params.items()})

        try:
            with st.spinner("Running query..."):
                df = run_query(engine, query, params)
                
            st.success(f"Query returned **{len(df):,}** row(s).")

            # --- KPI cards for numeric output columns ---
            numeric_output_cols = [
                c for c in output_columns
                if c in df.columns and pd.api.types.is_numeric_dtype(df[c])
            ]

            if numeric_output_cols:
                st.subheader("📈 KPI Summary")
                if show_in_crores:
                    st.caption("💰 Sum/Average shown in Crores (÷1,00,00,000).")
                for col in numeric_output_cols:
                    series = df[col].dropna()
                    c1, c2, c3 = st.columns(3)
                    c1.metric(f"Total Sum — {col}", format_amount(series.sum(), show_in_crores))
                    c2.metric(
                        f"Average — {col}",
                        format_amount(series.mean(), show_in_crores) if len(series) else format_amount(0, show_in_crores),
                    )
                    c3.metric(f"Count — {col}", f"{series.count():,}")
                st.divider()

            # --- Data table ---
            st.subheader("📋 Results")
            st.dataframe(df, use_container_width=True, height=450)
            st.caption(f"Total rows: **{len(df):,}** | Columns: {', '.join(df.columns)}")

            # --- Download button ---
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            st.download_button(
                label="⬇️ Download CSV",
                data=csv_buffer.getvalue(),
                file_name=f"{selected_table}_report.csv",
                mime="text/csv",
                use_container_width=True,
            )
        except SQLAlchemyError as exc:
            st.error(f"❌ Query failed: {exc}")
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Unexpected error while running the query: {exc}")

with tab_pivot:
    st.subheader("🧮 Quadrant Summary Table")

    if not show_pivot_table:
        st.info(
            "👈 Enable **'Show monthly cumulative summary / Pivot Table'** in the sidebar "
            "(section 4️⃣) to build a pivot table."
        )
    elif not pivot_row_cols:
        st.info("👈 Choose at least one **Rows** column in the sidebar to build a pivot table.")
    elif not pivot_value_cols:
        st.info("👈 Choose at least one numeric **Values** column in the sidebar to aggregate.")
    elif not pivot_is_built:
        st.info("👈 Configure Filters / Rows / Columns / Values in the sidebar, then click **Build Summary** once. It'll then stay live and update automatically as you change your selections or use the calculator below.")
    else:
        try:
            filter_conditions = tuple(
                (fc, tuple(pivot_filter_values.get(fc, []))) for fc in pivot_filter_cols
            )

            with st.spinner("Aggregating data in the database..."):
                pivot_source_dfs = fetch_pivot_source_data_multi(
                    engine,
                    selected_table,
                    tuple(pivot_row_cols),
                    tuple(pivot_col_cols),
                    tuple(pivot_value_cols),
                    filter_conditions,
                    column_kind_map,
                )
            master_grid_applied = False
            if include_master_grid and df_master is not None and not df_master.empty:
                _expanded, _skip_msg = {}, None
                for vc, sdf in pivot_source_dfs.items():
                    _expanded[vc], _m = expand_source_with_master_grid(
                        sdf, df_master, list(pivot_row_cols), column_kind_map
                    )
                    _skip_msg = _skip_msg or _m
                if _skip_msg:
                    st.warning(f"Master hierarchy not applied: {_skip_msg}.")
                else:
                    pivot_source_dfs = _expanded
                    master_grid_applied = True
            pivot_source_df = pivot_source_dfs[pivot_value_cols[0]]  # first Values column -- used below by the Chart, Field Efficiency Table, and DPD buckets

            if any(df.empty for df in pivot_source_dfs.values()):
                st.warning("No rows match the selected filters — nothing to pivot.")
            else:
                # Flat/chart view uses each date field at its exact-date leaf
                # granularity only (matching the original single-level
                # behaviour) -- the Summary Matrix below is the one that
                # shows the full Month > Date nesting.
                flat_row_cols = [_date_field_leaf(f, column_kind_map) for f in pivot_row_cols]
                flat_col_cols = [_date_field_leaf(f, column_kind_map) for f in pivot_col_cols]

                # A Rows selection with several fields creates one row per
                # PARENT GROUP at every level -- not just one per leaf
                # combination -- so the Summary Matrix's total row count can
                # be far larger than len(pivot_source_df) itself (e.g. a
                # 6-level Zone > Sub Zone > Region > New Region > Area >
                # Branch hierarchy). A many-thousand-row STYLED table is what
                # actually freezes the browser, regardless of how fast the
                # database query or the Python aggregation is -- so this is
                # checked BEFORE committing to building/rendering it. It's
                # cheap: a handful of drop_duplicates() calls on the already-
                # small aggregated table, not a full tree construction.
                matrix_row_fields = []
                for field in pivot_row_cols:
                    if column_kind_map.get(field) == "date":
                        matrix_row_fields.extend([f"__{field}__month", f"__{field}__date"])
                    else:
                        matrix_row_fields.append(field)
                estimated_pivot_rows = 1  # Grand Total
                for k in range(1, len(matrix_row_fields) + 1):
                    estimated_pivot_rows += pivot_source_df[matrix_row_fields[:k]].drop_duplicates().shape[0]
                matrix_col_fields = []
                for field in pivot_col_cols:
                    if column_kind_map.get(field) == "date":
                        matrix_col_fields.extend([f"__{field}__month", f"__{field}__date"])
                    else:
                        matrix_col_fields.append(field)
                if matrix_col_fields:
                    estimated_matrix_cols = pivot_source_df[matrix_col_fields].drop_duplicates().shape[0]
                    for depth in range(1, len(matrix_col_fields)):
                        estimated_matrix_cols += pivot_source_df[matrix_col_fields[:depth]].drop_duplicates().shape[0]
                    if len(matrix_col_fields) >= 2 and pivot_right_total_mode in ("deepest_field_total", "both"):
                        estimated_matrix_cols += pivot_source_df[matrix_col_fields[-1]].nunique(dropna=True)
                    has_deepest_totals = (
                        len(matrix_col_fields) >= 2
                        and pivot_right_total_mode in ("deepest_field_total", "both")
                    )
                    if pivot_right_total_mode in ("grand_total", "both") or not has_deepest_totals:
                        estimated_matrix_cols += 1
                else:
                    estimated_matrix_cols = 1
                estimated_output_cells = estimated_pivot_rows * estimated_matrix_cols * len(pivot_value_cols)
                PIVOT_RENDER_ROW_LIMIT = 3000
                PIVOT_RENDER_CELL_LIMIT = 250_000
                render_override_key = f"force_render_large_pivot_{selected_table}"
                render_override_signature = (
                    tuple(pivot_row_cols),
                    tuple(pivot_col_cols),
                    tuple(pivot_value_cols),
                    filter_conditions,
                    pivot_agg_func,
                    pivot_right_total_mode,
                    bool(include_master_grid),
                    len(df_master) if include_master_grid and df_master is not None else 0,
                )
                signature_key = f"{render_override_key}_signature"
                if st.session_state.get(signature_key) != render_override_signature:
                    st.session_state[render_override_key] = False
                    st.session_state[signature_key] = render_override_signature
                pivot_render_allowed = (
                    (
                        estimated_pivot_rows <= PIVOT_RENDER_ROW_LIMIT
                        and estimated_output_cells <= PIVOT_RENDER_CELL_LIMIT
                    )
                    or st.session_state.get(render_override_key, False)
                )

                pivot_df = None
                if pivot_include_flat_export:
                    with st.spinner("Building additional flat pivot export..."):
                        pivot_df = build_pivot_table(
                            pivot_source_df, flat_row_cols, flat_col_cols, pivot_agg_func
                        )

                st.success(
                    f"Pivot built from **{len(pivot_source_df):,}** aggregated group(s) — "
                    f"**{pivot_agg_func}({', '.join(pivot_value_cols)})** by **{', '.join(pivot_row_cols)}**"
                    + (f" × **{', '.join(pivot_col_cols)}**" if pivot_col_cols else "")
                )
                if master_grid_applied:
                    st.caption(f"🗂️ Master hierarchy applied — all {len(df_master):,} master rows are shown (rows with no data display 0).")
                st.caption(
                    "Aggregated server-side in PostgreSQL (GROUP BY, with date fields auto-bucketed by month) — "
                    "every view below is built from this small aggregated table, not from the raw rows."
                )

                if pivot_render_allowed:
                    st.markdown("#### 📋 Summary Matrix")
                    if len(pivot_value_cols) == 1:
                        display_pivot_df, matrix_group_flags, matrix_total_flags = render_excel_style_pivot_table(
                            pivot_source_df,
                            pivot_row_cols,
                            pivot_col_cols,
                            pivot_value_cols[0],
                            pivot_agg_func,
                            column_kind_map,
                            pivot_show_in_crores,
                            pivot_right_total_mode,
                        )
                    else:
                        display_pivot_df, matrix_group_flags, matrix_total_flags = render_multi_value_pivot_table(
                            pivot_source_dfs,
                            pivot_row_cols,
                            pivot_col_cols,
                            pivot_value_cols,
                            pivot_agg_func,
                            column_kind_map,
                            pivot_show_in_crores,
                            pivot_right_total_mode,
                            pivot_column_hierarchy_order,
                        )

                    prepare_matrix_excel = st.checkbox(
                        "Prepare formatted Summary Matrix Excel download",
                        value=False,
                        key=f"pivot_matrix_excel_{selected_table}",
                        help="Workbook formatting can take time for large pivots, so it is generated only when requested.",
                    )
                    if prepare_matrix_excel:
                        matrix_value_kind = "count" if pivot_agg_func == "count" else "number"
                        display_xlsx_bytes = dataframe_to_formatted_excel_bytes(
                            display_pivot_df, matrix_group_flags, matrix_total_flags,
                            value_kind=matrix_value_kind, table_style="matrix", sheet_name="Summary Matrix",
                        )
                        st.download_button(
                            "⬇️ Download Summary Matrix Excel (with subtotals)",
                            data=display_xlsx_bytes,
                            file_name=f"{selected_table}_pivot_excel_style.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True,
                            key=f"download_pivot_excel_style_{selected_table}",
                        )

                    # --- Optional: cumulative DPD buckets (1+ / 30+ / 90+) ------ #
                    # Opt-in since most pivots built with this generic tool won't
                    # be about DPD slabs at all -- only offered when one of the
                    # chosen Columns fields actually looks like a DPD slab field.
                    # Kept to the single-Values-column case: with 2+ Values
                    # columns the header already has an extra outer level, which
                    # would shift where the DPD slab level sits.
                    if pivot_col_cols and len(pivot_value_cols) == 1:
                        add_dpd_buckets = st.checkbox(
                            "➕ Add cumulative DPD buckets (1+ / 30+ / 90+) to the Summary Matrix",
                            value=False,
                            key=f"add_dpd_buckets_{selected_table}",
                            help=(
                                "Sums the raw DPD slab columns (e.g. '1-29', '30-59', '60-89', '90+') "
                                "into cumulative macro-buckets: 1+ = all delinquent slabs, "
                                "30+ = 30-59/60-89/90+, 90+ = the 90+ slab alone. Requires one of "
                                "your Columns fields to hold the raw DPD slab labels, and — if you've "
                                "picked 2+ Columns fields — that field must be listed FIRST."
                            ),
                        )
                        if add_dpd_buckets:
                            dpd_field_choice = st.selectbox(
                                "Which Columns field holds the DPD slab?",
                                options=pivot_col_cols,
                                index=0,
                                key=f"dpd_field_choice_{selected_table}",
                            )
                            try:
                                slab_level = _effective_col_level(pivot_col_cols, dpd_field_choice, column_kind_map)
                                display_pivot_df = add_dpd_buckets_to_excel_pivot(
                                    display_pivot_df, slab_level, only_show_buckets=True
                                )
                                st.markdown("##### ➕ Summary Matrix — Cumulative DPD Buckets (1+ / 30+ / 90+)")
                                num_fmt = "{:,.0f}" if pivot_agg_func == "count" else "{:,.2f}"
                                # Columns changed shape (bucket columns appended), so
                                # total-column flags are re-derived from the current
                                # column labels rather than reusing the pre-DPD list;
                                # rows are untouched, so matrix_group_flags still applies.
                                if isinstance(display_pivot_df.columns, pd.MultiIndex):
                                    dpd_total_flags = [str(t[-1]).strip().endswith("Total") for t in display_pivot_df.columns]
                                else:
                                    dpd_total_flags = [str(c).strip().endswith("Total") for c in display_pivot_df.columns]
                                display_virtualized_pivot(
                                    display_pivot_df, matrix_group_flags, dpd_total_flags, num_fmt,
                                    grid_key=f"aggrid_dpd_matrix_{selected_table}",
                                )
                            except ValueError as exc:
                                st.warning(f"⚠️ Couldn't add DPD buckets: {exc}")
                    elif pivot_col_cols and len(pivot_value_cols) > 1:
                        st.caption(
                            "ℹ️ DPD bucket columns (1+/30+/90+) are only offered when exactly one "
                            "Values column is selected."
                        )

                    use_flow_retention = st.checkbox(
                        "🔀 Use Flow / Normalised / Stabilized / Roll Back retention % instead (100% − Flow%)",
                        value=False,
                        key=f"pivot_flow_retention_{selected_table}",
                        help=(
                            "Per row group: 100 - (Flow / (Flow+Normalised+Stabilized+RollBack) × 100), "
                            "computed from the Summary Matrix above. Only makes sense when your Rows are "
                            "nested like Slab > Flow/Normalised/Stabilized(/Roll Back). Leave unchecked for "
                            "the normal Field Efficiency Table below (used for other cases)."
                        ),
                    )

                    if use_flow_retention:
                        st.markdown("#### 🎯 Flow Retention % (100% − Flow%)")
                        st.caption(
                            "Per row group: 100 − (Flow ÷ (Flow + Normalised + Stabilized + Roll Back) × 100), "
                            "straight from the Summary Matrix above. Groups with no Flow sub-row are skipped."
                        )
                        efficiency_display_df = compute_flow_retention_table(display_pivot_df)
                        if efficiency_display_df.empty:
                            st.warning(
                                "⚠️ No row group with a 'Flow' sub-row was found in the Summary Matrix above — "
                                "nothing to show. This needs Rows nested like Slab > Flow/Normalised/Stabilized."
                            )
                        else:
                            # Reuse the Summary Matrix's row grouping (parent/child
                            # rows, "↳ " nesting, bold subtotal rows) -- but only
                            # when Flow Retention's rows are exactly the Summary
                            # Matrix's rows (the Columns-nested case, where the
                            # row axis is untouched). If Flow Retention instead
                            # collapsed each Rows-group into a single row (the
                            # Rows-nested case), there are no sub-rows left to
                            # group, and the length check below skips this.
                            _flow_src_df = pivot_source_dfs[pivot_value_cols[0]]
                            _, flow_candidate_flags, _ = build_excel_style_pivot(
                                _flow_src_df, pivot_row_cols, pivot_col_cols, pivot_value_cols[0],
                                pivot_agg_func, column_kind_map, pivot_show_in_crores, pivot_right_total_mode,
                            )
                            flow_group_flags = (
                                flow_candidate_flags if len(flow_candidate_flags) == len(efficiency_display_df) else None
                            )

                            display_virtualized_pivot(
                                efficiency_display_df, flow_group_flags or [], [False] * efficiency_display_df.shape[1],
                                "{:,.2f}%",
                                grid_key=f"aggrid_flow_retention_{selected_table}",
                                row_axis_name=efficiency_display_df.index.name,
                            )

                            flow_xlsx_bytes = dataframe_to_formatted_excel_bytes(
                                efficiency_display_df,
                                group_row_flags=flow_group_flags,
                                value_kind="percent",
                                table_style="efficiency",
                                sheet_name="Flow Retention",
                            )
                            st.download_button(
                                "⬇️ Download Flow Retention Table Excel",
                                data=flow_xlsx_bytes,
                                file_name=f"{selected_table}_flow_retention.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True,
                                key=f"download_flow_retention_{selected_table}",
                            )

                    available_efficiency_fields = list(dict.fromkeys([*pivot_row_cols, *pivot_col_cols]))
                    if use_flow_retention:
                        pass  # already computed & shown above
                    elif available_efficiency_fields and st.checkbox(
                        "Build the additional Field Efficiency percentage table",
                        value=False,
                        key=f"pivot_build_efficiency_{selected_table}",
                        help="This is an additional full pivot calculation; enable it only when you need the percentage view.",
                    ):
                        st.markdown("#### 🎯 Field Efficiency Table (% of a chosen field's group total)")
                        st.caption(
                            "Pick any one of your selected Rows/Columns fields below — the table will show "
                            "each cell as that field's % share of the total across its own group, holding "
                            "every other selected field fixed. Works the same way whether you point it at a "
                            "Rows field or a Columns field."
                            + (
                                " Shown as one column block per Values column, side by side."
                                if len(pivot_value_cols) > 1 else ""
                            )
                        )
                        normalize_field = st.selectbox(
                            "Normalize as % across:",
                            options=available_efficiency_fields,
                            key=f"pivot_normalize_field_{selected_table}",
                        )
                        if len(pivot_value_cols) == 1:
                            efficiency_display_df, eff_group_row_flags, eff_render_total_flags = render_field_efficiency_table(
                                pivot_source_df,
                                pivot_row_cols,
                                pivot_col_cols,
                                normalize_field,
                                pivot_value_cols[0],
                                pivot_agg_func,
                                column_kind_map,
                            )
                        else:
                            efficiency_display_df, eff_group_row_flags, eff_render_total_flags = render_multi_value_field_efficiency_table(
                                pivot_source_dfs,
                                pivot_row_cols,
                                pivot_col_cols,
                                normalize_field,
                                pivot_value_cols,
                                pivot_agg_func,
                                column_kind_map,
                                pivot_column_hierarchy_order,
                            )

                        # --- Optional: cumulative DPD buckets on the % table too --- #
                        # Mathematically valid ONLY when normalizing across the same
                        # field that holds the DPD slabs -- every slab's % share then
                        # already shares one common denominator (the group total), so
                        # summing them into 1+/30+/90+ is exactly as correct as
                        # summing the raw values would be. Kept to the single-Values-
                        # column case: with 2+ Values columns the header already has
                        # an extra outer level, which would shift where the DPD slab
                        # level sits (same reasoning as the Summary Matrix version).
                        if pivot_col_cols and normalize_field in pivot_col_cols and len(pivot_value_cols) == 1:
                            add_dpd_buckets_eff = st.checkbox(
                                "➕ Add cumulative DPD buckets (1+ / 30+ / 90+) to the Field Efficiency Table",
                                value=False,
                                key=f"add_dpd_buckets_eff_{selected_table}",
                                help=(
                                    "Only offered here because you're normalizing across the same field "
                                    "that holds your DPD slab labels -- each slab's % already divides by "
                                    "the same group total, so 1+/30+/90+ can be built by summing those "
                                    "% columns directly, same as the Summary Matrix version above."
                                ),
                            )
                            if add_dpd_buckets_eff:
                                try:
                                    eff_slab_level = _effective_col_level(pivot_col_cols, normalize_field, column_kind_map)
                                    efficiency_display_df = add_dpd_buckets_to_excel_pivot(
                                        efficiency_display_df, eff_slab_level, only_show_buckets=True
                                    )
                                    st.markdown("##### ➕ Field Efficiency Table — Cumulative DPD Buckets (1+ / 30+ / 90+)")
                                    # Same reasoning as the Summary Matrix DPD block: columns
                                    # changed shape, so total-column flags are re-derived;
                                    # rows are untouched, so eff_group_row_flags still applies.
                                    if isinstance(efficiency_display_df.columns, pd.MultiIndex):
                                        eff_dpd_total_flags = [str(t[-1]).strip().endswith("Total") for t in efficiency_display_df.columns]
                                    else:
                                        eff_dpd_total_flags = [str(c).strip().endswith("Total") for c in efficiency_display_df.columns]
                                    display_virtualized_pivot(
                                        efficiency_display_df, eff_group_row_flags, eff_dpd_total_flags, "{:,.2f}%",
                                        grid_key=f"aggrid_dpd_efficiency_{selected_table}",
                                    )
                                except ValueError as exc:
                                    st.warning(f"⚠️ Couldn't add DPD buckets: {exc}")
                        elif pivot_col_cols and normalize_field in pivot_col_cols and len(pivot_value_cols) > 1:
                            st.caption(
                                "ℹ️ DPD bucket columns (1+/30+/90+) on this table are only offered when "
                                "exactly one Values column is selected."
                            )

                        # --- Optional: isolate one status value (e.g. only BOUNCED) ---
                        # Slicing happens AFTER the % table above was already computed
                        # over the full dataset, so BOUNCED% is still correctly
                        # BOUNCED / (BOUNCED + CLEARED + ...), never BOUNCED / BOUNCED.
                        status_values = [
                            str(v)
                            for v in pd.unique(
                                pivot_source_df[_date_field_leaf(normalize_field, column_kind_map)].dropna()
                            )
                        ]
                        isolate_status = st.selectbox(
                            f"Show only one value of `{normalize_field}` (optional)",
                            options=["(show all)"] + status_values,
                            key=f"pivot_eff_isolate_{selected_table}",
                        )
                        if isolate_status != "(show all)":
                            try:
                                efficiency_display_df = slice_field_efficiency_to_status(
                                    efficiency_display_df, normalize_field, isolate_status
                                )
                                st.markdown(f"##### 🎯 {isolate_status} only")
                                # Rows are untouched by isolate-to-one-status (only
                                # columns are sliced), so eff_group_row_flags still
                                # applies; the Total column is dropped, so no column
                                # is flagged as a total column here.
                                if isinstance(efficiency_display_df.columns, pd.MultiIndex):
                                    iso_total_flags = [str(t[-1]).strip().endswith("Total") for t in efficiency_display_df.columns]
                                else:
                                    iso_total_flags = [str(c).strip().endswith("Total") for c in efficiency_display_df.columns]
                                display_virtualized_pivot(
                                    efficiency_display_df, eff_group_row_flags, iso_total_flags, "{:,.2f}%",
                                    grid_key=f"aggrid_isolate_status_{selected_table}",
                                )
                            except ValueError as exc:
                                st.warning(f"⚠️ Couldn't isolate '{isolate_status}': {exc}")

                        # Total columns are normally exactly what the render call
                        # above already returned (correct for either hierarchy
                        # order) -- but the DPD-bucket / "isolate one status"
                        # steps above can change the table's shape, in which case
                        # we re-derive from the current columns: with the default
                        # "Values -> Columns" order "Total" is always the LAST
                        # level; with the "Columns -> Values" swap active it's
                        # one of the OUTER levels instead (the last level there is
                        # always the "<Agg> of <value col>" label, never "Total").
                        eff_col_tuples = (
                            list(efficiency_display_df.columns)
                            if isinstance(efficiency_display_df.columns, pd.MultiIndex)
                            else [(c,) for c in efficiency_display_df.columns]
                        )
                        if len(eff_render_total_flags) == len(eff_col_tuples):
                            eff_total_flags = eff_render_total_flags
                        elif len(pivot_value_cols) > 1 and pivot_column_hierarchy_order == "col_then_value":
                            eff_total_flags = [any(str(x).strip() == "Total" for x in t[:-1]) for t in eff_col_tuples]
                        else:
                            eff_total_flags = [str(t[-1]).strip() == "Total" for t in eff_col_tuples]

                        if st.checkbox(
                            "Prepare Field Efficiency Excel download",
                            value=False,
                            key=f"pivot_efficiency_excel_{selected_table}",
                        ):
                            efficiency_xlsx_bytes = dataframe_to_formatted_excel_bytes(
                                efficiency_display_df, group_row_flags=eff_group_row_flags, total_col_flags=eff_total_flags,
                                value_kind="percent", table_style="efficiency", sheet_name="Field Efficiency",
                            )
                            st.download_button(
                                "⬇️ Download Field Efficiency Table Excel",
                                data=efficiency_xlsx_bytes,
                                file_name=f"{selected_table}_pivot_efficiency_{normalize_field}.xlsx",
                                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                use_container_width=True,
                                key=f"download_pivot_efficiency_{selected_table}",
                            )
                    else:
                        efficiency_display_df = None

                    if pivot_include_flat_export and pivot_df is not None:
                        flat_value_kind = "count" if pivot_agg_func == "count" else "number"
                        pivot_xlsx_bytes = dataframe_to_formatted_excel_bytes(
                            pivot_df, value_kind=flat_value_kind, table_style="matrix", sheet_name="Pivot (flat)"
                        )
                        st.download_button(
                            "⬇️ Download Pivot Excel (flat)",
                            data=pivot_xlsx_bytes,
                            file_name=f"{selected_table}_pivot_summary.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            use_container_width=True,
                            key=f"download_pivot_{selected_table}",
                        )
                        if len(pivot_value_cols) > 1:
                            st.caption(f"Flat file reflects your first Values column, `{pivot_value_cols[0]}`, only.")
                else:
                    st.warning(
                        f"⚠️ This Rows selection ({', '.join(pivot_row_cols)}) would produce roughly "
                        f"**{estimated_pivot_rows:,} rows** once every level's own subtotal row is included "
                        f"across about **{estimated_matrix_cols:,} matrix columns** ({estimated_output_cells:,} cells across selected Values). "
                        "The render limit protects both rows and total output size. Add a **Filter**, remove a high-cardinality field, "
                        "or reduce Columns / Values. You can still explicitly force rendering below."
                    )
                    if st.button(
                        "Render anyway (may be slow, could freeze the browser)",
                        key=f"force_render_large_pivot_btn_{selected_table}",
                    ):
                        st.session_state[render_override_key] = True
                        st.rerun()
        except SQLAlchemyError as exc:
            st.error(f"❌ Failed to fetch data for the pivot table: {exc}")
        except Exception as exc:  # noqa: BLE001
            st.error(f"❌ Unexpected error while building the pivot table: {exc}")

if tab_sql is not None:
    with tab_sql:
        st.subheader("🧑‍💻 Custom SQL Execution")
        st.info("Write and execute standard PostgreSQL queries directly against your database.")
    
        # Text area for the user to type queries
        custom_query = st.text_area("SQL Query", height=200, placeholder='SELECT * FROM "public"."agreements" LIMIT 100;')
    
        if st.button("▶️ Run Custom Query", type="primary"):
            if custom_query.strip():
                try:
                    with st.spinner("Executing query..."):
                        with engine.connect() as conn:
                            # Uses the existing engine to run the custom text query
                            custom_df = pd.read_sql(text(custom_query), conn)
                
                    st.success(f"Query returned **{len(custom_df):,}** row(s).")
                    st.dataframe(custom_df, use_container_width=True, height=400)

                    
                    custom_csv = io.StringIO()
                    custom_df.to_csv(custom_csv, index=False)
                    st.download_button(
                        label="⬇️ Download Custom Results (CSV)",
                        data=custom_csv.getvalue(),
                        file_name="custom_sql_results.csv",
                        mime="text/csv",
                        use_container_width=True,
                    )
                except Exception as exc:
                    st.error(f"❌ Query failed: {exc}")
            else:
                st.warning("Please enter a SQL query first.")
