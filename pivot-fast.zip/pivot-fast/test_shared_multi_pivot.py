"""Regression checks for the shared multi-measure Excel-style pivot builder."""
import unittest

import numpy as np
import pandas as pd

import db_core as core


class SharedMultiPivotTest(unittest.TestCase):
    @staticmethod
    def _sources():
        dims = pd.DataFrame({
            "zone": ["North", "North", "North", "South", "South", "South"],
            "branch": ["A", "A", "B", "C", "D", "D"],
            "stage": ["X", "Y", "X", "X", "Y", "Y"],
            "__posted__month": ["2025-01", "2025-01", "2025-02", "2025-02", "2025-02", "2025-03"],
            "__posted__date": ["2025-01-01", "2025-01-02", "2025-02-01", "2025-02-02", "2025-02-03", "2025-03-01"],
        })
        first = dims.copy()
        first[core.STAT_SUM] = [10.0, 20.0, 0.0, 7.0, 9.0, 1.0]
        first[core.STAT_COUNT] = [1, 2, 0, 1, 1, 1]
        first[core.STAT_MIN] = [10.0, 5.0, np.nan, 7.0, 9.0, 1.0]
        first[core.STAT_MAX] = [10.0, 15.0, np.nan, 7.0, 9.0, 1.0]

        second = dims.copy()
        second[core.STAT_SUM] = [2.0, 0.0, 15.0, 4.0, 12.0, 8.0]
        second[core.STAT_COUNT] = [1, 0, 3, 1, 2, 1]
        second[core.STAT_MIN] = [2.0, np.nan, 3.0, 4.0, 5.0, 8.0]
        second[core.STAT_MAX] = [2.0, np.nan, 7.0, 4.0, 7.0, 8.0]
        # Deliberately reverse the second measure: the shared builder must
        # align it by group keys and not assume that all inputs have same order.
        return {"amount_a": first, "amount_b": second.iloc[::-1].reset_index(drop=True)}

    def test_shared_results_match_single_measure_builder(self):
        sources = self._sources()
        values = ["amount_a", "amount_b"]
        kinds = {"posted": "date"}
        row_cols = ["zone", "branch"]
        col_cols = ["stage", "posted"]

        for agg_func in core.PIVOT_AGG_FUNCS:
            for total_mode in ("grand_total", "deepest_field_total", "both"):
                expected = {
                    value: core.build_excel_style_pivot(
                        source, row_cols, col_cols, value, agg_func, kinds, False, total_mode
                    )
                    for value, source in sources.items()
                }
                for hierarchy_order in ("value_then_col", "col_then_value"):
                    with self.subTest(agg=agg_func, totals=total_mode, order=hierarchy_order):
                        actual_df, actual_rows, actual_cols = core.build_excel_style_pivot_multi(
                            sources,
                            row_cols,
                            col_cols,
                            values,
                            agg_func,
                            kinds,
                            False,
                            total_mode,
                            hierarchy_order,
                        )
                        self.assertEqual(actual_rows, expected[values[0]][1])
                        for value in values:
                            label = f"{agg_func.title()} of {value}"
                            measure_level = 0 if hierarchy_order == "value_then_col" else -1
                            actual_block = actual_df.xs(label, axis=1, level=measure_level, drop_level=True)
                            pd.testing.assert_frame_equal(
                                actual_block,
                                expected[value][0],
                                check_dtype=False,
                                check_names=False,
                                check_exact=False,
                                rtol=1e-10,
                                atol=1e-10,
                            )
                        if hierarchy_order == "value_then_col":
                            self.assertEqual(actual_cols, expected[values[0]][2] * len(values))
                        else:
                            self.assertEqual(
                                actual_cols,
                                [flag for flag in expected[values[0]][2] for _ in values],
                            )

    def test_shared_results_match_without_columns_fields(self):
        first = pd.DataFrame({
            "team": ["A", "B"],
            core.STAT_SUM: [3.0, 7.0],
            core.STAT_COUNT: [1, 1],
            core.STAT_MIN: [3.0, 7.0],
            core.STAT_MAX: [3.0, 7.0],
        })
        second = first.copy()
        second[core.STAT_SUM] = [9.0, 1.0]
        second[core.STAT_MIN] = [9.0, 1.0]
        second[core.STAT_MAX] = [9.0, 1.0]
        sources = {"amount_a": first, "amount_b": second}

        for agg_func in core.PIVOT_AGG_FUNCS:
            expected = {
                value: core.build_excel_style_pivot(source, ["team"], [], value, agg_func, {}, False)
                for value, source in sources.items()
            }
            for hierarchy_order in ("value_then_col", "col_then_value"):
                actual, _, _ = core.build_excel_style_pivot_multi(
                    sources, ["team"], [], list(sources), agg_func, {}, False,
                    column_hierarchy_order=hierarchy_order,
                )
                for value in sources:
                    label = f"{agg_func.title()} of {value}"
                    level = 0 if hierarchy_order == "value_then_col" else -1
                    block = actual.xs(label, axis=1, level=level)
                    np.testing.assert_allclose(
                        block.to_numpy(), expected[value][0].to_numpy(), equal_nan=True
                    )


if __name__ == "__main__":
    unittest.main(verbosity=2)
