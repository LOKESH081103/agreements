import { useState } from "react";
import api from "../api.js";

export default function CustomSql() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function run() {
    if (!query.trim()) {
      setError("Please enter a SQL query first.");
      return;
    }
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const { data } = await api.post("/sql", { query });
      setResult(data);
    } catch (e) {
      setError(e.response?.data?.error || e.message);
    } finally {
      setBusy(false);
    }
  }

  function downloadCsv() {
    if (!result?.rows?.length) return;
    const header = result.fields.join(",");
    const body = result.rows
      .map((r) => result.fields.map((f) => `"${String(r[f] ?? "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob([`${header}\n${body}`], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "custom_sql_results.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div>
      <div className="card card-pad">
        <div className="section-title">🧑‍💻 Query Editor</div>
        <p style={{ fontSize: 13, marginBottom: 14 }}>
          Write and execute read-only <code>SELECT</code>/<code>WITH</code> queries directly against the database.
        </p>
        <textarea
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder='SELECT * FROM "public"."agreements" LIMIT 100;'
          rows={8}
          style={{ width: "100%", fontFamily: "var(--font-mono)", fontSize: 13, resize: "vertical" }}
        />
        <div style={{ marginTop: 14 }}>
          <button onClick={run} disabled={busy} className="btn btn-primary">
            {busy ? (<><span className="spinner" /> Running…</>) : "▶ Run Custom Query"}
          </button>
        </div>

        {error && <div className="banner banner-error" style={{ marginTop: 16, marginBottom: 0 }}>❌&nbsp; {error}</div>}
      </div>

      {result && (
        <div className="card card-pad fade-in" style={{ marginTop: 18 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
            <div className="section-title" style={{ marginBottom: 0 }}>
              📄 Results &nbsp;<span style={{ color: "var(--text-muted)", fontWeight: 500 }}>· {result.rowCount.toLocaleString()} row(s)</span>
            </div>
            <button onClick={downloadCsv} className="btn btn-secondary btn-sm">⬇ CSV</button>
          </div>
          <div className="table-wrap" style={{ maxHeight: 420 }}>
            <table className="data-table">
              <thead>
                <tr>
                  {result.fields.map((f) => (
                    <th key={f}>{f}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {result.rows.slice(0, 500).map((r, i) => (
                  <tr key={i}>
                    {result.fields.map((f) => (
                      <td key={f}>{String(r[f] ?? "")}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
