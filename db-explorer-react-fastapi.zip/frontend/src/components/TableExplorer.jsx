import { useCallback, useEffect, useRef, useState } from "react";
import api, { downloadBlob, errorMessage, isCanceled, reportPayload } from "../api.js";
import KpiCards from "./KpiCards.jsx";
import ChartView from "./ChartView.jsx";

export default function TableExplorer() {
  const [tables, setTables] = useState([]);
  const [table, setTable] = useState("");
  const [columns, setColumns] = useState([]);
  const [refColumn, setRefColumn] = useState("");
  const [outputColumns, setOutputColumns] = useState([]);
  const [dateMode, setDateMode] = useState("Year(s)");
  const [years, setYears] = useState([]);
  const [selectedYears, setSelectedYears] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [report, setReport] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const requestRef = useRef(null);

  useEffect(() => {
    const controller = new AbortController();
    api.get("/tables", { signal: controller.signal }).then(({ data }) => setTables(data)).catch((e) => !isCanceled(e) && setError(errorMessage(e, "Could not load tables.")));
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (!table) return;
    const controller = new AbortController();
    setColumns([]); setRefColumn(""); setReport(null); setError("");
    api.get(`/tables/${encodeURIComponent(table)}/columns`, { signal: controller.signal }).then(({ data }) => setColumns(data)).catch((e) => !isCanceled(e) && setError(errorMessage(e, "Could not load columns.")));
    return () => controller.abort();
  }, [table]);

  const refKind = columns.find((column) => column.name === refColumn)?.kind;

  useEffect(() => {
    if (!table || !refColumn) return;
    const controller = new AbortController();
    setSelectedYears([]); setSelectedCategories([]); setYears([]); setCategories([]);
    const path = refKind === "date"
      ? `/tables/${encodeURIComponent(table)}/year-months/${encodeURIComponent(refColumn)}`
      : `/tables/${encodeURIComponent(table)}/distinct/${encodeURIComponent(refColumn)}`;
    api.get(path, { signal: controller.signal }).then(({ data }) => {
      if (refKind === "date") setYears([...new Set(data.map(([year]) => Number(year)))].sort());
      else setCategories(data);
    }).catch((e) => !isCanceled(e) && setError(errorMessage(e, "Could not load filter values.")));
    return () => controller.abort();
  }, [table, refColumn, refKind]);

  const runReport = useCallback(async () => {
    if (!table || !refColumn || !refKind) return;
    requestRef.current?.abort();
    const controller = new AbortController();
    requestRef.current = controller;
    setBusy(true); setError("");
    let filterPayload = {};
    if (refKind === "date" && selectedYears.length) filterPayload = { granularity: dateMode, years: selectedYears };
    if (refKind !== "date" && selectedCategories.length) filterPayload = { categories: selectedCategories };
    try {
      const { data } = await api.post(`/tables/${encodeURIComponent(table)}/report`, reportPayload(refColumn, refKind, outputColumns.length ? outputColumns : columns.map((c) => c.name), filterPayload), { signal: controller.signal });
      setReport(data);
    } catch (e) { if (!isCanceled(e)) setError(errorMessage(e, "Report failed.")); }
    finally { if (!controller.signal.aborted) setBusy(false); }
  }, [table, refColumn, refKind, outputColumns, columns, dateMode, selectedYears, selectedCategories]);

  async function download(format) {
    if (!table || !refColumn || !refKind) return;
    setError("");
    const filterPayload = refKind === "date" ? { granularity: dateMode, years: selectedYears } : { categories: selectedCategories };
    try {
      await downloadBlob(api.post(`/tables/${encodeURIComponent(table)}/report`, reportPayload(refColumn, refKind, outputColumns.length ? outputColumns : columns.map((c) => c.name), filterPayload), { responseType: "blob" }), `${table}_report.${format}`);
    } catch (e) { setError(errorMessage(e, "Download failed.")); }
  }

  const rows = report?.rows || [];
  const firstRow = rows[0] || {};
  return <div>
    {error && <div className="banner banner-error">{error}</div>}
    <div className="card card-pad">
      <div className="section-title">Data Source</div>
      <div className="field-row">
        <Field label="Select table"><select value={table} onChange={(e) => setTable(e.target.value)}><option value="">Choose a table</option>{tables.map((t) => <option key={t} value={t}>{t}</option>)}</select></Field>
        <Field label="Reference column"><select value={refColumn} onChange={(e) => setRefColumn(e.target.value)} disabled={!columns.length}><option value="">Choose a column</option>{columns.map((c) => <option key={c.name} value={c.name}>{c.name} · {c.kind}</option>)}</select></Field>
      </div>
      {columns.length > 0 && <Field label="Output columns (optional)"><select multiple value={outputColumns} onChange={(e) => setOutputColumns([...e.target.selectedOptions].map((o) => o.value))} style={{ minWidth: 280, minHeight: 110 }}>{columns.map((c) => <option key={c.name} value={c.name}>{c.name}</option>)}</select></Field>}
      {refKind === "date" && <div className="field-row"><Field label="Date filter"><select value={dateMode} onChange={(e) => setDateMode(e.target.value)}><option>Year(s)</option><option>Month/Year</option></select></Field><Field label="Year(s)"><select multiple value={selectedYears.map(String)} onChange={(e) => setSelectedYears([...e.target.selectedOptions].map((o) => Number(o.value)))} style={{ minWidth: 160, minHeight: 90 }}>{years.map((y) => <option key={y} value={y}>{y}</option>)}</select></Field></div>}
      {(refKind === "text" || refKind === "numeric") && <Field label={`Filter ${refColumn}`}><select multiple value={selectedCategories.map(String)} onChange={(e) => setSelectedCategories([...e.target.selectedOptions].map((o) => o.value))} style={{ minWidth: 280, minHeight: 100 }}>{categories.map((v) => <option key={String(v)} value={v}>{String(v)}</option>)}</select></Field>}
      <button className="btn btn-primary" disabled={!table || !refColumn || busy} onClick={runReport}>{busy ? <><span className="spinner" /> Loading without blocking…</> : "Run Report"}</button>
    </div>
    {report && <><KpiCards numericCols={Object.keys(report.kpis || {}).filter((key) => key !== "record_count")} kpis={report.kpis} />{rows.length > 0 && <div className="card card-pad fade-in" style={{ marginTop: 18 }}><div className="section-title">Results · {rows.length.toLocaleString()} rows <button className="btn btn-secondary btn-sm" onClick={() => download("csv")}>Download CSV</button></div><div className="table-wrap" style={{ maxHeight: 480 }}><table className="data-table"><thead><tr>{Object.keys(firstRow).map((key) => <th key={key}>{key}</th>)}</tr></thead><tbody>{rows.slice(0, 500).map((row, index) => <tr key={index}>{Object.keys(firstRow).map((key) => <td key={key}>{String(row[key] ?? "")}</td>)}</tr>)}</tbody></table></div></div>}</>}
  </div>;
}

function Field({ label, children }) { return <div className="field"><label>{label}</label>{children}</div>; }
