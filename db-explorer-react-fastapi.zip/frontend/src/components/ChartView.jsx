import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";

const MONTHS = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export default function ChartView({ data, valueKey = "record_count", label = "Count" }) {
  if (!data?.length) return null;
  const chartData = data.map((d) => ({
    ...d,
    label: d.label ?? `${MONTHS[d.mo]} ${d.yr}`,
  }));

  return (
    <div className="card card-pad fade-in" style={{ margin: "18px 0" }}>
      <div style={{ width: "100%", height: 360 }}>
        <ResponsiveContainer>
          <BarChart data={chartData} margin={{ top: 10, right: 16, left: 0, bottom: 40 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#eef0f6" vertical={false} />
            <XAxis
              dataKey="label"
              angle={-40}
              textAnchor="end"
              interval={0}
              height={70}
              tick={{ fontSize: 11.5, fill: "#8891a3" }}
              axisLine={{ stroke: "#e4e8f1" }}
              tickLine={false}
            />
            <YAxis
              label={{ value: label, angle: -90, position: "insideLeft", fill: "#8891a3", fontSize: 11.5 }}
              tick={{ fontSize: 11.5, fill: "#8891a3" }}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              cursor={{ fill: "rgba(99, 102, 241, 0.06)" }}
              contentStyle={{
                borderRadius: 10,
                border: "1px solid #e4e8f1",
                boxShadow: "0 4px 12px rgba(16,24,40,0.1)",
                fontSize: 12.5,
              }}
            />
            <Legend wrapperStyle={{ fontSize: 12.5 }} />
            <defs>
              <linearGradient id="barFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#6366f1" />
                <stop offset="100%" stopColor="#4338ca" />
              </linearGradient>
            </defs>
            <Bar dataKey={valueKey} name={label} fill="url(#barFill)" radius={[5, 5, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
