"""Focused, database-free regression test for combined measure aggregation."""
import unittest
from unittest.mock import patch

import pandas as pd

import db_core as core


class _Connection:
    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        return False


class _Engine:
    def connect(self):
        return _Connection()


class MultiMeasurePivotTest(unittest.TestCase):
    def test_one_query_preserves_measure_stats_and_totals(self):
        calls = []

        def fake_read_sql(query, _conn, params=None):
            calls.append((str(query), params))
            return pd.DataFrame({
                "team": ["A", "A", "B"],
                "period": ["Mar", "Apr", "Mar"],
                "__multi_0_sum__": [30, 10, 8],
                "__multi_0_count__": [2, 1, 1],
                "__multi_0_min__": [10, 10, 8],
                "__multi_0_max__": [20, 10, 8],
                "__multi_1_sum__": [100, 50, 10],
                "__multi_1_count__": [1, 1, 1],
                "__multi_1_min__": [100, 50, 10],
                "__multi_1_max__": [100, 50, 10],
            })

        with patch.object(core.pd, "read_sql", side_effect=fake_read_sql):
            result = core.fetch_pivot_source_data_multi(
                _Engine(),
                "facts",
                ("team",),
                ("period",),
                ("march_amt", "april_amt"),
                (("region", ("north",)),),
                {"team": "text", "period": "text"},
            )

        self.assertEqual(len(calls), 1)
        self.assertEqual(list(result), ["march_amt", "april_amt"])
        self.assertEqual(result["march_amt"][core.STAT_SUM].tolist(), [30, 10, 8])
        self.assertEqual(result["march_amt"][core.STAT_COUNT].tolist(), [2, 1, 1])
        self.assertEqual(result["april_amt"][core.STAT_SUM].tolist(), [100, 50, 10])
        self.assertIn(":pf_0_0", calls[0][0])
        self.assertEqual(calls[0][1], {"pf_0_0": "north"})

        mean = core._combine_group_stats(result["march_amt"], [], "mean").iloc[0]
        self.assertAlmostEqual(mean, 12.0)  # 48 total / 4 non-null values
        matrix, _, _ = core.build_excel_style_pivot(
            result["march_amt"],
            ["team"],
            ["period"],
            "march_amt",
            "sum",
            {"team": "text", "period": "text"},
            False,
        )
        self.assertEqual(matrix.loc["Grand Total", "Grand Total"], 48)


if __name__ == "__main__":
    unittest.main(verbosity=2)
