# DB Explorer & Pivot Summary — Optimized Copy

This folder contains the optimized Streamlit application (`app.py`) and shared database/pivot module (`db_core.py`). Your original uploaded files were left unchanged.

## What was improved

- **Multiple Values fields now use one grouped SQL query.** The query computes sum, non-null count, minimum, and maximum for each selected measure at the same time, instead of rescanning/grouping the source table separately for each measure. Counts remain measure-specific, so mean calculations stay correct when measures have different null patterns.
- **The extra Field Efficiency table is optional.** It is computed only after you select its checkbox.
- **Excel workbook generation is optional/on-demand.** The formatted Summary Matrix and Field Efficiency workbooks are not built until their download checkboxes are selected.
- **The flat Excel export is optional.** Select its sidebar checkbox only when you need it; it uses the first selected Values field as before.
- **Large-output protection considers both rows and cells.** The app estimates the row hierarchy and column hierarchy before rendering. It proceeds automatically up to 3,000 estimated rows and 250,000 estimated output cells; beyond that, filter/reduce the pivot or explicitly choose “Render anyway” with caution.

The visible pivot still computes and displays the selected measures and hierarchy. Totals, subtotals, and mean semantics are preserved. Performance depends on table size, filters, distinct dimension counts, PostgreSQL resources, and network latency.

## Requirements

- Python 3.10 or newer (Python 3.11 recommended)
- PostgreSQL database reachable from the machine running Streamlit
- Database account with `SELECT` on the report tables and permission to create the app's authentication tables on first run; the app owner/admin should also be able to provision authorized employees

## Install and run (Linux/macOS)

1. Extract/copy this folder to a stable location.
2. From this folder, create and activate a virtual environment:

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

3. Install packages:

   ```bash
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

4. Create your private configuration file and edit it with your PostgreSQL connection settings:

   ```bash
   cp .env.example .env
   ```

   **Important:** this app reads its Streamlit database configuration before `db_core.py` loads `.env`. Export the values into the shell before launching Streamlit:

   ```bash
   set -a
   source .env
   set +a
   streamlit run app.py
   ```

   Keep `.env` private and never commit/share it. Alternatively, export the `DB_*` variables directly in your shell, or configure them using Streamlit secrets in a supported deployment. If you use `DATABASE_URL`, make sure credentials with reserved URL characters are percent-encoded; using the separate `DB_*` settings avoids that issue.

5. Open the local URL printed by Streamlit (normally `http://localhost:8501`).

### Windows PowerShell

Create the environment and install dependencies as above, using `py -m venv .venv`, then activate with `.venv\Scripts\Activate.ps1`. Set the database environment variables in that PowerShell session (for example, `$env:DB_HOST = "localhost"`, `$env:DB_NAME = "your_database"`, `$env:DB_USER = "your_user"`, `$env:DB_PASSWORD = "your_password"`, and `$env:DB_SSLMODE = "prefer"`), then run:

```powershell
streamlit run app.py
```

## First-run authentication setup

On startup, the app creates `authorized_employees`, `app_users`, and `login_audit` if they do not exist. **Account creation is restricted to employee codes already in `authorized_employees`.** A database administrator should insert/authorize at least one initial administrator before users can create accounts. For example, after confirming the employee details and access level, run this once in the target database:

```sql
INSERT INTO authorized_employees
    (employee_code, employee_name, department, access_level, is_authorized)
VALUES
    ('EMP001', 'Initial Administrator', 'IT', 'admin', TRUE)
ON CONFLICT (employee_code) DO UPDATE
SET employee_name = EXCLUDED.employee_name,
    department = EXCLUDED.department,
    access_level = EXCLUDED.access_level,
    is_authorized = TRUE;
```

Replace the example values with a real, approved employee record. Then log in using that employee code and create its app password through the **Create Account** tab. The application user will need the normal permissions required by this app; avoid granting broad database privileges unless your deployment requires them.

## Build a pivot summary

1. Log in, select the database table, and enable **Show monthly cumulative summary / Pivot Table** in the sidebar.
2. Add selective **Filters** first when possible. Choose the required **Rows**, **Columns**, and **Values** fields, then choose the aggregation.
3. Click **Build Summary**. The selected measures are aggregated together in PostgreSQL. The Summary Matrix shows the chosen values, hierarchy, subtotals, and grand totals.
4. Enable **Build the additional Field Efficiency percentage table** only if you need that extra calculation.
5. Select **Prepare formatted Summary Matrix Excel download** only when you need a workbook. Select **Prepare the additional flat Pivot Excel download** in the sidebar only when you need the separate flat-format workbook.
6. For a pivot blocked by the output-size guard, reduce cardinality/fields or add a filter. “Render anyway” bypasses the guard and can use substantial memory or freeze the browser.

The source query cache lasts up to 10 minutes. If underlying data changed and you need it immediately, use Streamlit's **Clear cache** control and rebuild the summary. Treat this cache window as a freshness choice when deploying the app.

## Validation performed for this copy

- Python syntax compilation for both modules.
- A mocked database-result test confirmed that two Values fields are served by one query, filters remain parameterized, each measure retains independent sum/count/min/max statistics, mean uses sum divided by its own count, and the existing pivot builder produces the expected grand total.

There is no database connection or credentials included in this package, so end-to-end testing against your PostgreSQL data remains to be done in your environment. Before production use, compare old and new results for representative filters, null patterns, all aggregation modes, date dimensions, master hierarchy behavior, and totals.
